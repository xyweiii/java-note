package com.sms.sioo;

import com.sms.sioo.core.service.handle.eventbus.BatchFailObserver;
import com.sms.sioo.core.service.handle.eventbus.EventBusCenter;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.scheduling.annotation.EnableScheduling;

/**
 * @Author: creep
 * @Date: 2018/12/17 下午1:51
 */
@SpringBootApplication
@EnableScheduling
public class SiooSmsApplication {
    public static void main(String[] args) {
        SpringApplication.run(SiooSmsApplication.class, args);
        //TODO
        BatchFailObserver batchFailObserver = new BatchFailObserver();
        EventBusCenter.register(batchFailObserver);
    }
}
