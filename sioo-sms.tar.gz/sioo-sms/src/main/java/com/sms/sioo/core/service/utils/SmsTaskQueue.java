package com.sms.sioo.core.service.utils;

import com.alibaba.fastjson.JSONObject;

import java.util.concurrent.LinkedBlockingQueue;

/**
 * @Author: creep
 * @Date: 2018/12/20 下午7:05
 */
public class SmsTaskQueue {

    /**
     * 保存批次信息 MongoDB 表：sms_msg_batch
     */
    public static LinkedBlockingQueue<JSONObject> SAVE_BATCH_QUEUE = new LinkedBlockingQueue<>();

    /**
     * 更新批次信息 MongoDB 表：sms_msg_batch
     */
    public static LinkedBlockingQueue<JSONObject> UPDATE_BATCH_QUEUE = new LinkedBlockingQueue<>();

    /**
     * 保存审核详情表信息 MongoDB 表：sms_msg_verify
     */
    public static LinkedBlockingQueue<JSONObject> SAVE_VERIFY_QUEUE = new LinkedBlockingQueue<>();




    /**
     * 保存详情信息 MongoDB 表：sms_msg_dtl
     */
    public static LinkedBlockingQueue<JSONObject> SAVE_DTL_QUEUE = new LinkedBlockingQueue<>();


    /**
     * 状态表入库 mysql 表：sms_rpt_dtl
     */
    public static LinkedBlockingQueue<JSONObject> INSERT_STATUS_QUEUE = new LinkedBlockingQueue<>();

}
