package com.sms.sioo.core.service.repository.data;

import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.Date;

/**
 * Project:sioo-sms
 * File: com.sms.sioo.core.service.repository.data
 *
 * @author : xywei
 * @date : 2019-01-11
 * Copyright 2006-2019 Sioo Co., Ltd. All rights reserved.
 */

/**
 * 短信详情表
 *
 * @author xywei
 */
@Document(collection = "sms_msg_dtl")
@Data
public class MsgDetailData {

    @Id
    private String id;

    /**
     * 批次id
     */
    private Long batchId;

    /**
     * 唯一id
     */
    private Long uniqueId;

    /**
     * 用户userId
     */
    private String userId;

    /**
     * 租户Id
     */
    private String tenantId;

    /**
     * 用户单价
     */
    private String price;
    /**
     * 所属地区
     */
    private String location;

    /**
     * 用户提交时间
     */
    private Long userSubDate;

    /**
     * 通道提交时间
     */
    private Long chnSubDate;

    /**
     * 手机号码
     */
    private String mobile;
    /**
     * 手机号运营商
     */
    private Integer mtype;

    /**
     * 信息来源  0:api接口数据  1:Web数据
     */
    private String source;

    /**
     * 触发审核标志 boolean类型数据
     */
    private String release;

    /**
     * 短信内容
     */
    private String content;

    /**
     * 内容条数
     */
    private Integer contentNum;

    /**
     * 签名拓展码
     */
    private String extNo;

    /**
     * 通道id
     */
    private String channelId;

    /**
     * 系统rptCode
     */
    private String sysRptCode;

    /**
     * 通道rptCode
     */
    private String chnRptCode;

    /**
     * 通道回执时间rptDate
     */
    private Long chnRptDate;

    /**
     * 提交成功数
     */
    private Integer subSucc;

    /**
     * 提交失败数
     */
    private Integer subFail;

    /**
     * 校验成功数
     */
    private Integer rptSucc;

    /**
     * 校验失败数
     */
    private Integer rptFail;

    /**
     * 创建时间
     */
    private Date createDate = new Date();

    /**
     * 更新时间
     */
    private Date updateDate = new Date();
}
