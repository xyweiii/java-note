package com.sms.sioo.core.service.pojo;

import lombok.Data;

import java.util.Date;

/**
 * 用户模板
 */

@Data
public class UserTemplate {


    /**
     * 用户id
     */
    private String userId;

    /**
     * 租户id
     */
    private String tenantId;

    /**
     * 模板内容
     */
    private String content;

    /**
     * 状态 0:待审核，1审核通过，2驳回
     */
    private int status;

    /**
     * 类型 0:永久模板，1:临时模板
     */
    private int type;

    /**
     * 失效日期
     */

    private Date endDate;

    public String getContent() {
        content = content.replaceAll("\\(", "\\\\(")
                .replaceAll("\\)", "\\\\)")
                .replaceAll("\\^", "\\\\^")
                .replaceAll("\\$", "\\\\$")
                .replaceAll("\\?", "\\\\?")
                .replaceAll("\\+", "\\\\+")
                .replaceAll("\\*", "\\\\*")
                .replaceAll("\\|", "\\\\|");
        content = content.replaceAll("\\[\\#", "(").replaceAll("\\#\\]", ")");
        return content;
    }
}
