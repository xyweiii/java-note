package com.sms.sioo.core.service.pojo;

import lombok.Getter;
import lombok.Setter;

/**
 * 通道签名表
 */
@Getter
@Setter
public class ChannelExtNo {

    /**
     * 用户名
     */
    private Integer channelId;

    /**
     * 拓展号
     */
    private String extNo;

    /**
     * 签名
     */
    private String sign;

    private Integer cid;

}
