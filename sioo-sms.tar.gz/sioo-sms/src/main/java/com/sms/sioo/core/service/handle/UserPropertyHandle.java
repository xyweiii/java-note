package com.sms.sioo.core.service.handle;

import com.alibaba.fastjson.JSONObject;
import com.sms.sioo.core.service.handle.constant.MsgConstant;
import com.sms.sioo.core.service.pojo.MobileArea;
import com.sms.sioo.core.service.pojo.UserInfo;
import com.sms.sioo.core.service.utils.SmsCache;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

/**
 * @Author: creep
 * @Date: 2018/12/24 下午2:59
 */
@Service
public class UserPropertyHandle {

    private static final Logger LOGGER = LoggerFactory.getLogger(UserPropertyHandle.class);

    /**
     * 默认归属地
     */
    public static String defaultLocation = "全国,-1";

    @Value("${sioo.sms.mobile.yd}")
    public String ydMobile;

    @Value("${sioo.sms.mobile.lt}")
    public String ltMobile;

    @Value("${sioo.sms.mobile.dx}")
    public String dxMobile;

    public JSONObject updateProperty(JSONObject msg, UserInfo user) {
        String sysRptCode = msg.getString("sysRptCode");
        if (StringUtils.isNotBlank(sysRptCode)) {
            return msg;

        }
        // TODO: 19-1-14 号段对应地区处理
        MobileArea area = SmsCache.MOBILE_AREA.get(Integer.parseInt(msg.getLong("mobile").toString().substring(0, 7)));
        if (area != null) {
            msg.put("location", area.getProvince());
            msg.put("provinceCode", area.getProvinceCode());
            msg.put("cityCode", area.getCityCode());
        } else {
            msg.put("location", defaultLocation);
            msg.put("provinceCode", 0);
            msg.put("cityCode", 0);
        }
        //extNo
        if (msg.getString(MsgConstant.EXTNO) != null && msg.getString(MsgConstant.EXTNO).length() > 20) {
            msg.put("extNo", msg.getString("extNo").substring(0, 20));
        }
        msg.put("mtype", findMobileType(msg.getString("mobile")));
        // TODO: 19-1-10 获取用户 通道组id
        if (msg.getInteger("mtype") == 1) {
            msg.put("channelGroupId", user.getMobile());
        } else if (msg.getInteger("mtype") == 2) {
            msg.put("channelGroupId", user.getUnicom());
        } else if (msg.getInteger("mtype") == 4) {
            msg.put("channelGroupId", user.getTelecom());
        }
        if (user.getApiRpt() == 0) {
            msg.put("apiRpt", true);
        } else {
            msg.put("apiRpt", false);
        }
        msg.put("resendMax", user.getFailResend());
        return msg;
    }

    /**
     * 根据电话号码获取 运营商
     *
     * @param mobile
     * @return
     */
    public int findMobileType(String mobile) {
        if (mobile.matches(ydMobile)) {
            return 1;
        } else if (mobile.matches(ltMobile)) {
            return 2;
        } else if (mobile.matches(dxMobile)) {
            return 4;
        } else {
            return 0;
        }
    }
}
