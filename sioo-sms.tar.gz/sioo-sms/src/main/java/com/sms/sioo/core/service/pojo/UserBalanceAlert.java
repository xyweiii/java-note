package com.sms.sioo.core.service.pojo;

import lombok.Getter;
import lombok.Setter;

/**
 * 用户余额提醒
 */
@Getter
@Setter
public class UserBalanceAlert {

    /**
     * 用户名
     */
    private Integer userName;

    /**
     * 提醒号码（多个号码使用英文逗号隔开）
     */
    private String mobile;

    /**
     * 提醒条数
     */
    private Integer num;

    /**
     * 提醒时间（当天几点）
     */
    private Integer senddate;

    /**
     * 祝福短信内容
     */
    private String content;
}
