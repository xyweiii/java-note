package com.sms.sioo.core.service.scheduler;

import com.sms.sioo.core.service.utils.SmsCache;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

/**
 * 重号过滤保存
 */
@Component
public class RepeatClear {

    private static final Logger LOG = LoggerFactory.getLogger(RepeatClear.class);

    List<String> list = new ArrayList<>();

    @Scheduled(cron="0 1 0 * * ?")//每天0点1分触发
    public void handle(){
        try {
            SmsCache.REPEAT_MAP.clear();
        } catch (Exception e) {
            LOG.error(e.getMessage(),e);
        }
    }

}
