package com.sms.sioo.core.service.handle;

import com.alibaba.fastjson.JSONObject;
import com.sms.sioo.core.service.handle.tools.DataTools;
import com.sms.sioo.core.service.pojo.UserInfo;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.concurrent.CompletableFuture;


/**
 * @author xywei
 */
@Service
public class CoreHandle {

    private static final Logger LOGGER = LoggerFactory.getLogger(CoreHandle.class);


    @Autowired
    private FishMobileHandle fishMobileHandle;

    @Autowired
    private RepeatMobileHandle repeatMobileHandle;

    @Autowired
    private BlackAndWhiteMobileHandle blackAndWhiteMobileHandle;

    @Autowired
    private SignHandle signHandle;

    @Autowired
    private ChargingHandle chargingHandle;

    @Autowired
    private BlackAreaHandle blackAreaHandle;

    @Autowired
    private Sendhandle sendhandle;

    @Autowired
    private UserPropertyHandle userPropertyHandle;

    /**
     * @Description:
     * @param: [msg]
     * @return: com.alibaba.fastjson.JSONObject
     * @author: creep
     * @Time: 2018/12/24 下午4:52
     */
    public JSONObject executeHandle(JSONObject msg, UserInfo user) {
        try {
            //短信拆分,如果是批次发送拆分多条
            List<JSONObject> list = DataTools.convert(msg);
            //逐条校验
            list.forEach(json ->
                    CompletableFuture.supplyAsync(() -> userPropertyHandle.updateProperty(json, user))
                            //添加签名和拓展以及channelId
                            .thenApplyAsync(signHandle::executeHandle)
                            //余额校验  user传递过去，避免再次查找缓存
                            .thenApplyAsync(p -> chargingHandle.executeHandle(p, user))
                            //钓鱼号码校验
                            .thenApplyAsync(fishMobileHandle::executeHandle)
                            //号码去重校验
                            .thenApplyAsync(p1 -> repeatMobileHandle.executeHandle(p1, user))
                            //黑白名单校验
                            .thenApplyAsync(blackAndWhiteMobileHandle::executeHandle)
                            //屏蔽地区校验(用户屏蔽地区校验,通道屏蔽地区校验)
                            .thenApplyAsync(blackAreaHandle::executeHandle)
                            //对消息进行处理(1:审核 2:发送 3:校验失败)
                            .thenAcceptAsync(sendhandle::executeHandle)
            );
        } catch (Exception e) {
            LOGGER.info("[CoreHandle]:校验信息出现异常,msg:" + msg.toString());
        }
        return null;
    }
}
