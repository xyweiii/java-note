package com.sms.sioo.core.service.dao;

/**
 * Project:sioo-tenant
 * File: com.sioo.server.dao
 *
 * @author : xywei
 * @date : 2018-12-19
 * Copyright 2006-2018 Sioo Co., Ltd. All rights reserved.
 */

import org.apache.ibatis.annotations.Mapper;


@Mapper
public interface SignatureDao {

    int countByStatus();

}