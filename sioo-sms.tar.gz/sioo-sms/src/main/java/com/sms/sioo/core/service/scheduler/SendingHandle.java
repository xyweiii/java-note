/*
package com.sms.sioo.core.service.scheduler;

import com.alibaba.fastjson.JSONObject;
import com.sms.sioo.core.service.dao.ManagerBaseDao;
import com.sms.sioo.core.service.pojo.ChannelConnection;
import com.sms.sioo.core.service.pojo.UserInfo;
import com.sms.sioo.core.service.utils.SmsCache;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.AmqpException;
import org.springframework.amqp.core.AmqpTemplate;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.jdbc.datasource.DataSourceUtils;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.Clock;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

*/
/**
 * 审核短信处理
 *//*

public class SendingHandle implements Runnable {

    private static final Logger LOG = LoggerFactory.getLogger(SendingHandle.class);

    private ManagerBaseDao managerDao;

    private AmqpTemplate rabbitTemplate;

    private MongoTemplate mongoTemplate;

    public SendingHandle(ManagerBaseDao managerDao, AmqpTemplate rabbitTemplate, MongoTemplate mongoTemplate){
        this.managerDao = managerDao;
        this.rabbitTemplate = rabbitTemplate;
        this.mongoTemplate = mongoTemplate;
    }


    private void send(List<JSONObject> list){
        try {
            Map<Integer,List<Long>> dtlUpdate = new HashMap<>();
            Map<Long,Integer> batchUpdate = new HashMap<>();
            for(JSONObject obj : list){
                if(obj.getIntValue("handStat") == 1){//通过
                    UserInfo user = SmsCache.USERINFO.get(obj.getIntValue("userName"));
                    obj.put("priority",user.getPriority());
                    send(obj.getIntValue("channelId"), obj);
                }else{//驳回
                    LOG.info("驳回,"+obj.getString("mobile"));
                    JSONObject rpt = new JSONObject();
                    rpt.put("userName",obj.getIntValue("userName"));
                    rpt.put("cid",SmsCache.USERINFO.get(obj.getIntValue("userName")).getCid());
                    rpt.put("mobile",obj.getLong("mobile"));
                    rpt.put("rptCode","XA:0001");
                    rpt.put("uniqueId",obj.getLong("uniqueId"));
                    rpt.put("batchId",obj.getLong("batchId"));
                    rpt.put("rptTime", Clock.systemDefaultZone().millis());
                    rpt.put("channelId",obj.getInteger("channelId"));
                    rpt.put("extno",obj.getString("extNo"));
                    rpt.put("resendMax",0);
                    rpt.put("resendCount",0);
                    rpt.put("userSubTime",obj.getLong("senddate"));
                    rpt.put("channelSubTime",0);
                    rpt.put("price",obj.getDoubleValue("price"));
                    String key = obj.getInteger("userName")+"_"+ obj.getString("senddate").substring(0,8);
                    SmsCache.chargeCount(1, key, 0, 0,obj.getIntValue("contentNum"),0,0);
                    if(!dtlUpdate.containsKey(obj.getIntValue("contentNum"))){
                        List<Long> l = new ArrayList<>();
                        l.add(obj.getLongValue("uniqueId"));
                        dtlUpdate.put(obj.getIntValue("contentNum"),l);
                    }else{
                        dtlUpdate.get(obj.getIntValue("contentNum")).add(obj.getLongValue("uniqueId"));
                    }
                    if(!batchUpdate.containsKey(obj.getLongValue("batchId"))){
                        batchUpdate.put(obj.getLongValue("batchId"),obj.getIntValue("contentNum"));
                    }else{
                        batchUpdate.put(obj.getLongValue("batchId"),batchUpdate.get(obj.getLongValue("batchId"))+obj.getIntValue("contentNum"));
                    }
                    SmsCache.RPT_RESULT.add(rpt);
                }
            }
            if(dtlUpdate.size() > 0){
                for(Map.Entry<Integer,List<Long>> entry : dtlUpdate.entrySet()){
                    Update update = new Update();
                    update.set("subSucc",entry.getKey());
                    update.set("rptFail",entry.getKey());
                    mongoTemplate.updateMulti(new Query(Criteria.where("uniqueId").in(entry.getValue())),update,"sms_msg_dtl");
                }
            }
            if(batchUpdate.size() > 0){
                for(Map.Entry<Long,Integer> entry : batchUpdate.entrySet()){
                    Update update = new Update();
                    update.set("fail",entry.getValue());
                    mongoTemplate.updateMulti(new Query(Criteria.where("batchId").is(entry.getKey())),update,"sms_msg_batch");
                }
            }
        } catch (AmqpException e) {
            LOG.error(e.getMessage(),e);
        }
    }

    */
/**
     * 发送短信
     * @param channelId
     * @param obj
     *//*

    private void send(int channelId, JSONObject obj){
        try {
            Map<Integer, ChannelConnection> conn = SmsCache.CHANNEL_CONNCETION.get(channelId);
            if(conn==null || conn.size()==0){
                LOG.info("未找到消息队列："+obj.getString("mobile"));
                return;
            }else if(conn.size() == 1){
                for(Map.Entry<Integer,ChannelConnection> entry : conn.entrySet()){
                    rabbitTemplate.convertAndSend("sms.send","SEND_QUEUE_"+entry.getValue().getNo(),obj);
                    LOG.info("SEND_QUEUE_"+entry.getValue().getNo()+","+obj.getString("mobile"));
                    return;
                }
            }else if(conn.size() == 3){
                ChannelConnection connection = conn.get(SmsCache.USERINFO.get(obj.getIntValue("userName")).getUserKind());
                rabbitTemplate.convertAndSend("sms.send","SEND_QUEUE_"+connection.getNo(),obj);
                LOG.info("SEND_QUEUE_"+connection.getNo()+","+obj.getString("mobile"));
                return;
            }else{
                ChannelConnection connection = null;
                int userKind = SmsCache.USERINFO.get(obj.getIntValue("userName")).getUserKind();
                if(userKind==1){
                    connection = conn.get(2);
                }else if(userKind==2){
                    connection = conn.get(3);
                }else{
                    connection = conn.get(2);
                }
                rabbitTemplate.convertAndSend("sms.send","SEND_QUEUE_"+connection.getNo(),obj);
                LOG.info("SEND_QUEUE_"+connection.getNo()+","+obj.getString("mobile"));
                return;
            }
        } catch (AmqpException e) {
            LOG.error(e.getMessage(),e);
        }
    }

    */
/**
     * When an object implementing interface <code>Runnable</code> is used
     * to create a thread, starting the thread causes the object's
     * <code>run</code> method to be called in that separately executing
     * thread.
     * <p>
     * The general contract of the method <code>run</code> is that it may
     * take any action whatsoever.
     *
     * @see Thread#run()
     *//*

    @Override
    public void run() {
        while (true){
            try {
                List<JSONObject> list = new ArrayList<>();
                Connection conn = DataSourceUtils.getConnection(managerDao.getSqlSession().getConfiguration().getEnvironment().getDataSource());
//            Connection conn = managerDao.getSqlSession().getConfiguration().getEnvironment().getDataSource().getConnection();
                int count = 0;
                do{
                    PreparedStatement pstmt = conn.prepareStatement("SELECT id,mtype,senddate,username,mobile,channel,content,content_num,batch_id,grade,extno," +
                            "remark,unique_id,hand_stat,location FROM sioo_paas.sms_sending WHERE hand_stat>0 LIMIT 1000;");
                    ResultSet rs = pstmt.executeQuery();
                    StringBuilder sb = new StringBuilder();
                    while(rs.next()){
                        sb.append(rs.getLong("id")).append(",");
                        JSONObject obj = new JSONObject();
                        obj.put("mtype",rs.getInt("mtype"));
                        obj.put("senddate",rs.getLong("senddate"));
                        obj.put("userName",rs.getInt("userName"));
                        obj.put("mobile",rs.getLong("mobile"));
                        obj.put("channelId",rs.getInt("channel"));
                        obj.put("content",rs.getString("content"));
                        obj.put("contentNum",rs.getInt("content_num"));
                        obj.put("batchId",rs.getLong("batch_id"));
                        obj.put("grade",rs.getInt("grade"));
                        obj.put("extNo",rs.getString("extno"));
                        obj.put("remark",rs.getString("remark"));
                        obj.put("uniqueId",rs.getLong("unique_id"));
                        obj.put("handStat",rs.getInt("hand_stat"));
                        obj.put("location",rs.getString("location"));
                        list.add(obj);
                    }
                    rs.close();
                    if(sb.length() > 1){
                        pstmt.executeUpdate("DELETE FROM sioo_paas.sms_sending WHERE id in("+sb.substring(0,sb.length()-1)+");");
                    }
                    pstmt.close();
                    DataSourceUtils.releaseConnection(conn,managerDao.getSqlSession().getConfiguration().getEnvironment().getDataSource());
                    send(list);
                    count = list.size();
                    list.clear();
                }while (count == 1000);
                conn.close();
            } catch (SQLException e) {
                LOG.error(e.getMessage(),e);
            }
            try {
                Thread.sleep(200);
            } catch (InterruptedException e) {
            }
        }
    }
}
*/
