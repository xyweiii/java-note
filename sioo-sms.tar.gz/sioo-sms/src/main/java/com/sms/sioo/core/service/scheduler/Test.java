package com.sms.sioo.core.service.scheduler;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.mongodb.client.result.UpdateResult;
import com.sms.sioo.core.service.repository.data.MsgBatchData;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Component;

import javax.annotation.PostConstruct;
import java.util.Date;

/**
 * Project:sioo-sms
 * File: com.sms.sioo.core.service.scheduler
 *
 * @author : xywei
 * @date : 2019-01-16
 * Copyright 2006-2019 Sioo Co., Ltd. All rights reserved.
 */
@Component
public class Test {


    @Autowired
    private MongoTemplate mongoTemplate;


    @PostConstruct
    public void init() {
        for (int i = 0; i < 100; i++) {
            JSONObject msg = new JSONObject();
            msg.put("userId", i);
            msg.put("batchId", i);
            msg.put("mobileNum", 1);

            Criteria criteria = Criteria.where("batchId").is(i);
            Update update = Update.update("updateDate", new Date())
                    .inc("mobileNum", 1);
            UpdateResult updateResult = mongoTemplate.upsert(new Query(criteria), update, MsgBatchData.class);
            System.out.println(JSON.toJSONString(updateResult));
        }
    }
}
