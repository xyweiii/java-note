package com.sms.sioo.core.service.listener;

import com.alibaba.fastjson.JSONObject;
import com.sms.sioo.core.service.handle.SmsService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.rabbit.annotation.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadPoolExecutor;

@Component
@RabbitListener(bindings=@QueueBinding(value=@Queue("submit.http.advertise"),exchange=@Exchange("sms.submit")))
public class HttpAdvertiseListener {

    private static final Logger LOG = LoggerFactory.getLogger(HttpAdvertiseListener.class);

    private SmsService smsService;

    @RabbitHandler
    public void process(JSONObject message) {
        CompletableFuture.runAsync(()-> smsService.smsHandle(6,message));
    }
}
