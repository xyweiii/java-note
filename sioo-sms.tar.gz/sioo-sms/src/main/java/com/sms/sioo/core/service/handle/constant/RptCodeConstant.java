package com.sms.sioo.core.service.handle.constant;

/**
 * @Author: creep
 * @Date: 2018/12/25 下午2:29
 */
public class RptCodeConstant {

    /**
     * XA:0000 超过5分钟没有响应结果
     */
    public static final String SYS_STATUS_NORESPONSE = "XA:0000";

    /**
     * XA:0001 驳回失败
     */
    public static final String SYS_STATUS_REJECT = "XA:0001";

    /**
     * XA:0002 触发黑签名
     */
    public static final String SYS_STATUS_BLACKSIGN = "XA:0002";

    /**
     * XA:0004 触发自动屏蔽词
     */
    public static final String SYS_STATUS_AUTO_BLACK_WORD = "XA:0004";

    /**
     * XA:0100重号过滤
     */
    public static final String SYS_STATUS_REPEAT_MOBILE = "XA:0100";

    /**
     * XA:0140 触发屏蔽地区
     */
    public static final String SYS_STATUS_BLACK_LOCATION = "XA:0140";

    /**
     * XA:2140  用户屏蔽地区
     */
    public static final String SYS_STATUS_ALL_BLACK_MOBILE = "XA:2140";


    /**
     * XA:2006用户余额不足
     */
    public static final String USER_STATUS_NO_BLANCE = "XA:2006";


    /*########################*/

    /**
     * 用户不存在
     */
    public static final String USER_NOT_EXISTS = "XA:用户不存在";

    /**
     * 用户状态不正常
     */
    public static final String USER_STATUS_NOT_NORMAL = "XA:用户状态不正常";


    /**
     * XA:StrategyWord 系统屏蔽词
     */
    public static final String SYS_STATUS_STRATEGY_WORD = "XA:StrategyWord";

    /**
     * XA:userblackWord 用户屏蔽词
     */
    public static final String USER_STATUS_BLACK_WORD = "XA:userblackWord";

    /**
     * XA:系统审核 系统审核词
     */
    public static final String SYS_STATUS_EXAM_WORD = "XA:xxxxx";

    /**
     * XA:用户审核词 用户审核词
     */
    public static final String USER_STATUS_EXAM_WORD = "XA:xxxxxx";

    /**
     * XA:0139 触发系统黑名单
     */
    public static final String SYS_STATUS_BLACK_MOBILE = "XA:0139";

    /**
     * XA:0003 签名未报备
     */
    public static final String SYS_STATUS_NO_REPORT_SIGN = "XA:0003";

    /**
     * XA:2003 没有可用签名
     */
    public static final String USER_STATUS_NO_SIGN = "XA:2003";

    /**
     * XA:2004 没有可用通道
     */
    public static final String USER_STATUS_NO_CHANNEL = "XA:2004";

    /**
     * XA:2004 没有可用通道组
     */
    public static final String USER_STATUS_NO_CHANNEL_GROUP = "XA:2005";

    /**
     * XA:2139 触发用户黑名单
     */
    public static final String USER_STATUS_BLACK_MOBILE = "XA:2139";

    /**
     * user_black_area 用户屏蔽地区
     */
    public static final String USER_BLACK_AREA = "user_black_area";

    /**
     * user_black_area 通道屏蔽地区
     */
    public static final String CHANNEL_BLACK_AREA = "user_black_area";

    /**
     * user_repeat_mobile 重号校验
     */
    public static final String USER_REPEAT_MOBILE = "user_repeat_mobile";
}
