package com.sms.sioo.core.service.config.enums;

/**
 * Project:sioo-sms
 * File: com.sms.sioo.core.service.config.enums
 *
 * @author : xywei
 * @date : 2019-01-07
 * Copyright 2006-2019 Sioo Co., Ltd. All rights reserved.
 */
public enum ChannelStatus {

    /**
     * 接入中
     */
    JOINING(1, "接入中"),
    /**
     * 已驳回
     */
    REJECTED(2, "已驳回"),
    /**
     * 欠费
     */
    ARREARAGE(3, "欠费"),
    /**
     * 正常
     */
    NORMAL(4, "正常"),
    /**
     * 停用
     */
    STOP(5, "停用");

    private int code;
    private String description;

    ChannelStatus(int code, String description) {
        this.code = code;
        this.description = description;
    }

    public int getCode() {
        return code;
    }

    public String getDescription() {
        return description;
    }
}
