package com.sms.sioo.core.service.pojo;

import lombok.Getter;
import lombok.Setter;

/**
 * 用户白名单
 */
@Setter
@Getter
public class UserWhiteMobile {

    /**
     * 用户名
     */
    private Integer userName;

    /**
     * 号码
     */
    private Long mobile;
}
