package com.sms.sioo.core.service.pojo;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
/**
 * 用户审核/自动 屏蔽词
 */
public class UserShieldWords {

    /**
     * 用户名
     */
    private Integer userName;

    /**
     * 关键词
     */
    private String words;

    /**
     * 类型(1为审核词，2为自动词)
     */
    private Integer type;

    private Integer cid;
}
