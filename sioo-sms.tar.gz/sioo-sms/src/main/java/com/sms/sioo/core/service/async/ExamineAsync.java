/*
package com.sms.sioo.core.service.async;

import com.alibaba.fastjson.JSONObject;
import com.sms.sioo.core.service.dao.ManagerBaseDao;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.jdbc.datasource.DataSourceUtils;
import org.springframework.stereotype.Component;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.List;

*/
/**
 * 批量插入审核表
 *//*

@Component
public class ExamineAsync {

    private static final Logger LOG = LoggerFactory.getLogger(ExamineAsync.class);

    @Autowired
    private ManagerBaseDao managerDao;

    public void handle(List<JSONObject> list){
        try {
            long l = System.currentTimeMillis();
            Connection conn = DataSourceUtils.getConnection(managerDao.getSqlSession().getConfiguration().getEnvironment().getDataSource());
//            Connection conn = managerDao.getSqlSession().getConfiguration().getEnvironment().getDataSource().getConnection();
            conn.setAutoCommit(false);
            PreparedStatement pstmt = conn.prepareStatement("INSERT INTO sioo_paas.sms_release(mtype,senddate,username,mobile,channel,content,content_num,batch_id,grade,extno,remark,unique_id,mdstr,hand_stat,location,cid,price) VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?);");
            for(JSONObject obj : list){
                pstmt.setInt(1,obj.getIntValue("mtype"));
                pstmt.setLong(2,obj.getLongValue("senddate"));
                pstmt.setInt(3,obj.getIntValue("userName"));
                pstmt.setLong(4,obj.getLongValue("mobile"));
                pstmt.setInt(5,obj.getIntValue("channelId"));
                pstmt.setString(6,obj.getString("content"));
                pstmt.setInt(7,obj.getIntValue("contentNum"));
                pstmt.setLong(8,obj.getLongValue("batchId"));
                pstmt.setInt(9,obj.getIntValue("grade"));
                pstmt.setString(10,obj.getString("extno"));
                pstmt.setString(11,obj.getString("remark"));
                pstmt.setLong(12,obj.getLongValue("uniqueId"));
                pstmt.setString(13,obj.getString("mdstr"));
                pstmt.setInt(14,obj.getIntValue("handStat"));
                pstmt.setString(15,obj.getString("location"));
                pstmt.setInt(16,obj.getIntValue("cid"));
                pstmt.setDouble(17,obj.getDoubleValue("price"));
                pstmt.addBatch();
            }
            pstmt.executeBatch();
            conn.commit();
            pstmt.close();
            DataSourceUtils.releaseConnection(conn,managerDao.getSqlSession().getConfiguration().getEnvironment().getDataSource());
            LOG.info("batch insert release size[" + list.size() + "]time-consuming|" + (System.currentTimeMillis() - l));
        } catch (SQLException e) {
            LOG.error(e.getMessage(), e);
        }
    }

}
*/
