/*
package com.sms.sioo.core.service.scheduler;

import com.alibaba.fastjson.JSONObject;
import com.sms.sioo.core.service.config.redis.CacheUtils;
import com.sms.sioo.core.service.dao.ManagerBaseDao;
import com.sms.sioo.core.service.pojo.UserInfo;
import com.sms.sioo.core.service.utils.SmsCache;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.datasource.DataSourceUtils;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

*/
/**
 * 统计入库
 *//*

public class ReportSave implements Runnable {

    private static final Logger LOG = LoggerFactory.getLogger(ReportSave.class);

    private ManagerBaseDao managerDao;

    public ReportSave(ManagerBaseDao managerDao) {
        this.managerDao = managerDao;
    }


    */
/**
     * When an object implementing interface <code>Runnable</code> is used
     * to create a thread, starting the thread causes the object's
     * <code>run</code> method to be called in that separately executing
     * thread.
     * <p>
     * The general contract of the method <code>run</code> is that it may
     * take any action whatsoever.
     *
     * @see Thread#run()
     *//*

    @Override
    public void run() {
        while (true) {
            try {
                long l = System.currentTimeMillis();
                List<JSONObject> update = new ArrayList<>();
                List<JSONObject> insert = new ArrayList<>();
                int i = 0;
                Map<Integer, Double> smsMap = new HashMap<>();
                for (Map.Entry<String, String> entry : SmsCache.chargeMap.entrySet()) {
                    String[] k = entry.getKey().split("_");
                    //            key:username_senddate;value:send_unsend_fail_balance_sms
                    String[] v = SmsCache.chargeCount(2, entry.getKey(), 0, 0, 0, 0, 0).split("_");
                    JSONObject obj = new JSONObject();
                    obj.put("userName", Integer.parseInt(k[0]));
                    obj.put("sendDate", Integer.parseInt(k[1]));
                    obj.put("send", Integer.parseInt(v[0]));
                    obj.put("unsend", Integer.parseInt(v[1]));
                    obj.put("fail", Integer.parseInt(v[2]));
                    obj.put("balance", Double.parseDouble(v[3]));
                    obj.put("sms", Double.parseDouble(v[4]));
                    smsMap.put(obj.getIntValue("userName"), obj.getDoubleValue("sms"));
                    if (obj.getIntValue("send") == 0 && obj.getIntValue("unsend") == 0 && obj.getIntValue("fail") == 0) {
                        continue;
                    }
                    i++;
                    if (CacheUtils.isCached("userCount_" + entry.getKey())) {
                        update.add(obj);
                    } else {
                        CacheUtils.saveString("userCount_" + entry.getKey(), "", 24 * 3600);
                        insert.add(obj);
                    }
                }
                if (i != 0) {
                    try {
                        Connection conn = DataSourceUtils.getConnection(managerDao.getSqlSession().getConfiguration().getEnvironment().getDataSource());
                        conn.setAutoCommit(false);
                        if (insert != null && insert.size() > 0) {
                            PreparedStatement psInsert = conn.prepareStatement("INSERT INTO sioo_paas.user_day_count(username,sub_total,arrive_succ,arrive_fail,send_date,fail_return,company,correct,sms,cid,unsend) VALUES(?,?,?,?,?,?,?,?,?,?,?);");
                            for (JSONObject obj : insert) {
                                UserInfo user = SmsCache.USERINFO.get(obj.getIntValue("userName"));
                                psInsert.setInt(1, obj.getIntValue("userName"));
                                psInsert.setInt(2, obj.getIntValue("send"));
                                psInsert.setInt(3, 0);
                                psInsert.setInt(4, obj.getIntValue("fail"));
                                psInsert.setInt(5, obj.getIntValue("sendDate"));
                                psInsert.setInt(6, 0);
                                psInsert.setString(7, user.getCompany() + "");
                                psInsert.setInt(8, 0);
                                psInsert.setDouble(9, obj.getDoubleValue("balance"));
                                psInsert.setInt(10, user.getCid());
                                psInsert.setInt(11, obj.getIntValue("unsend"));
                                psInsert.addBatch();
                            }
                            psInsert.executeBatch();
                            conn.commit();
                        }
                        if (update != null && update.size() > 0) {
                            PreparedStatement psUpdates = conn.prepareStatement("UPDATE sioo_paas.user_day_count SET sub_total=sub_total+?,arrive_fail=arrive_fail+?,unsend=unsend+? WHERE username=? AND send_date=?");
                            PreparedStatement psUpdate = conn.prepareStatement("UPDATE sioo_paas.user_day_count SET sub_total=sub_total+?,sms=?,arrive_fail=arrive_fail+?,unsend=unsend+? WHERE username=? AND send_date=?");
                            boolean isUpdates = false, isUpdate = false;
                            for (JSONObject obj : update) {
                                if (obj.getDoubleValue("balance") > 0) {
                                    isUpdate = true;
                                    psUpdate.setInt(1, obj.getIntValue("send"));
                                    psUpdate.setDouble(2, obj.getDoubleValue("balance"));
                                    psUpdate.setInt(3, obj.getIntValue("fail"));
                                    psUpdate.setInt(4, obj.getIntValue("unsend"));
                                    psUpdate.setInt(5, obj.getIntValue("userName"));
                                    psUpdate.setInt(6, obj.getIntValue("sendDate"));
                                    psUpdate.addBatch();
                                } else {
                                    isUpdates = true;
                                    psUpdates.setInt(1, obj.getIntValue("send"));
                                    psUpdates.setInt(2, obj.getIntValue("fail"));
                                    psUpdates.setInt(3, obj.getIntValue("unsend"));
                                    psUpdates.setInt(4, obj.getIntValue("userName"));
                                    psUpdates.setInt(5, obj.getIntValue("sendDate"));
                                    psUpdates.addBatch();
                                }
                            }
                            if (isUpdates) {
                                psUpdates.executeBatch();
                            }
                            if (isUpdate) {
                                psUpdate.executeBatch();
                            }
                            conn.commit();
                        }
                        PreparedStatement psUpdate = conn.prepareStatement("UPDATE sioo_paas.user_info SET sms=sms-? WHERE username=?");
                        for (Map.Entry<Integer, Double> entry : smsMap.entrySet()) {
                            psUpdate.setDouble(1, entry.getValue());
                            psUpdate.setInt(2, entry.getKey());
                            psUpdate.addBatch();
                        }
                        psUpdate.executeBatch();
                        conn.commit();
                        DataSourceUtils.releaseConnection(conn, managerDao.getSqlSession().getConfiguration().getEnvironment().getDataSource());
                    } catch (Exception e) {
                        LOG.error(e.getMessage(), e);
                    }
                    LOG.info("update userCount[insert:" + (insert == null ? 0 : insert.size()) + ",update:" + (update == null ? 0 : update.size()) + "]|time-consuming:" + (System.currentTimeMillis() - l));
                }


            } catch (NumberFormatException e) {
                LOG.error(e.getMessage(), e);
            }
            try {
                Thread.sleep(5000);
            } catch (InterruptedException e) {
            }
        }
    }
}
*/
