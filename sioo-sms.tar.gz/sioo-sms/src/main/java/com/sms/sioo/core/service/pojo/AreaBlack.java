package com.sms.sioo.core.service.pojo;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
/**
 * 屏蔽地区
 */
public class AreaBlack {


    private String userId;

    /**
     * 类型：0用户 1通道
     */
    private Integer type;

    /**
     * 屏蔽省份
     */
    private Integer provinceCode;

    /**
     * 屏蔽地市，0为屏蔽所有
     */
    private Integer cityCode;

    /**
     * 通道ID
     */
    private String channelId;

    /**
     * 例外用户（即该用户不屏蔽）
     */
    private String excUid;

    /**
     * 路由通道
     */
    private Integer routeChannel;
}
