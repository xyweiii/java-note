package com.sms.sioo.core.service.executor;


import com.google.common.base.Preconditions;
import org.apache.commons.lang3.StringUtils;

import java.util.Map;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ExecutorService;

import static com.sms.sioo.core.service.utils.ConfigHelper.getInt;
import static com.sms.sioo.core.service.utils.ConfigHelper.getLong;


/**
 * Created by alain on 18/1/3.
 */
public class ServiceExecutorHolder {
    public static final ExecutorService coreServiceExecutor =
            ExecutorHolder.createMultiQueueThreadPool("core_service",
                    getInt("core_service.executor_number"),
                    getInt("core_service.coreSize"),
                    getInt("core_service.maxSize"),
                    getInt("core_service.executor_queue_capacity"),
                    getLong("core_service.reject_sleep_mills"));

    public static final ExecutorService cmppAdvertiseExecutor =
            ExecutorHolder.createMultiQueueThreadPool("cmpp_advertise",
                    getInt("cmpp_advertise.executor_number"),
                    getInt("cmpp_advertise.coreSize"),
                    getInt("cmpp_advertise.maxSize"),
                    getInt("cmpp_advertise.executor_queue_capacity"),
                    getLong("cmpp_advertise.reject_sleep_mills"));

    public static final ExecutorService cmppNormalExecutor =
            ExecutorHolder.createMultiQueueThreadPool("cmpp_normal",
                    getInt("cmpp_normal.executor_number"),
                    getInt("cmpp_normal.coreSize"),
                    getInt("cmpp_normal.maxSize"),
                    getInt("cmpp_normal.executor_queue_capacity"),
                    getLong("cmpp_normal.reject_sleep_mills"));

    public static final ExecutorService cmppPriorityExecutor =
            ExecutorHolder.createMultiQueueThreadPool("cmpp_priority",
                    getInt("cmpp_priority.executor_number"),
                    getInt("cmpp_priority.coreSize"),
                    getInt("cmpp_priority.maxSize"),
                    getInt("cmpp_priority.executor_queue_capacity"),
                    getLong("cmpp_priority.reject_sleep_mills"));


    public static final ExecutorService httpAdvertiseExecutor =
            ExecutorHolder.createMultiQueueThreadPool("http_dvertise",
                    getInt("http_dvertise.executor_number"),
                    getInt("http_dvertise.coreSize"),
                    getInt("http_dvertise.maxSize"),
                    getInt("http_dvertise.executor_queue_capacity"),
                    getLong("http_dvertise.reject_sleep_mills"));

    public static final ExecutorService httpNormalExecutor =
            ExecutorHolder.createMultiQueueThreadPool("http_normal",
                    getInt("http_normal.executor_number"),
                    getInt("http_normal.coreSize"),
                    getInt("http_normal.maxSize"),
                    getInt("http_normal.executor_queue_capacity"),
                    getLong("http_normal.reject_sleep_mills"));

    public static final ExecutorService httpPriorityExecutor =
            ExecutorHolder.createMultiQueueThreadPool("http_priority",
                    getInt("http_priority.executor_number"),
                    getInt("http_priority.coreSize"),
                    getInt("http_priority.maxSize"),
                    getInt("http_priority.executor_queue_capacity"),
                    getLong("http_priority.reject_sleep_mills"));


    private static final Map<String, ExecutorService> EXECUTOR_SERVICE_MAP = new ConcurrentHashMap<>();

    public static ExecutorService getExtracExecutorService(String depth) {
        Preconditions.checkArgument(StringUtils.isNotBlank(depth), "depth is blank");

        if (EXECUTOR_SERVICE_MAP.get(depth) != null) {
            return EXECUTOR_SERVICE_MAP.get(depth);
        }
        synchronized (ServiceExecutorHolder.class) {
            if (EXECUTOR_SERVICE_MAP.get(depth) != null) {
                return EXECUTOR_SERVICE_MAP.get(depth);
            }
            EXECUTOR_SERVICE_MAP.put(depth, ExecutorHolder.createMultiQueueThreadPool(
                    String.format("extract_service_depth_%s", depth),
                    getInt("extract_service.executor_number"),
                    getInt("extract_service.coreSize"),
                    getInt("extract_service.maxSize"),
                    getInt("extract_service.executor_queue_capacity"),
                    getLong("extract_service.reject_sleep_mills")));
            return EXECUTOR_SERVICE_MAP.get(depth);
        }

    }
}
