package com.sms.sioo.core.service.scheduler;

import com.alibaba.fastjson.JSONObject;
import com.sms.sioo.core.service.utils.SmsCache;
import com.sms.sioo.core.service.utils.SmsTaskQueue;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 状态入库
 */
public class FailRptHandle implements Runnable {

    private static final Logger LOG = LoggerFactory.getLogger(FailRptHandle.class);

    private MongoTemplate mongoTemplate;

    public FailRptHandle(MongoTemplate mongoTemplate){
        this.mongoTemplate = mongoTemplate;
    }

    /**
     * When an object implementing interface <code>Runnable</code> is used
     * to create a thread, starting the thread causes the object's
     * <code>run</code> method to be called in that separately executing
     * thread.
     * <p>
     * The general contract of the method <code>run</code> is that it may
     * take any action whatsoever.
     *
     * @see Thread#run()
     */
    @Override
    public void run() {
        while (true){
            try {
                List<JSONObject> list = new ArrayList<>();
                int count = SmsTaskQueue.UPDATE_BATCH_QUEUE.drainTo(list, 3000);
                if(count > 0){
                    //防止批次记录还未入库
                    Thread.sleep(200);
                    try{
                        Map<Long, Integer> bFailMap = new HashMap<>();
                        for(JSONObject obj : list){
                            if(System.currentTimeMillis() - new SimpleDateFormat("yyyyMMddHHmmss").parse(obj.getString("userSubTime")).getTime() < 3000){
                                SmsTaskQueue.UPDATE_BATCH_QUEUE.add(obj);
                                continue;
                            }
                            if(!bFailMap.containsKey(obj.getLongValue("batchId"))){
                                bFailMap.put(obj.getLongValue("batchId"),1);
                            }else{
                                bFailMap.put(obj.getLongValue("batchId"),bFailMap.get(obj.getLongValue("batchId"))+1);
                            }
                        }
                        for(Map.Entry<Long, Integer> map : bFailMap.entrySet()){
                            Query query = new Query();
                            query.addCriteria(Criteria.where("batchId").is(map.getKey()));
                            Update update = new Update();
                            update.inc("fail", map.getValue());
                            mongoTemplate.updateMulti(query, update, "sms_msg_batch");
                        }
                    }catch(Exception e){
                        LOG.error(e.getMessage(),e);
                    }finally {
                        list.clear();
                    }
                }
            } catch (Exception e) {
                LOG.error(e.getMessage(),e);
            }
            try {
                Thread.sleep(300);
            } catch (InterruptedException e) {
            }
        }
    }
}
