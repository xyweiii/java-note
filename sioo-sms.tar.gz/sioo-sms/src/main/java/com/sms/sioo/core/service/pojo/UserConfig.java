package com.sms.sioo.core.service.pojo;

import lombok.Data;

/**
 * Project:sioo-sms
 * File: com.sms.sioo.core.service.pojo
 *
 * @author : xywei
 * @date : 2019-01-16
 * Copyright 2006-2019 Sioo Co., Ltd. All rights reserved.
 */

@Data
public class UserConfig {

    /**
     * 重号过滤类型：0每天 1一天以上
     */
    private Integer duplicateFilteringType;
    /**
     * 重号过滤时间
     */
    private Integer duplicateFilteringTime;
    /**
     * 重号过滤数量
     */
    private Integer duplicateFilteringAmount;

}
