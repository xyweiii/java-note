package com.sms.sioo.core.service.handle;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.google.common.base.Preconditions;
import com.sms.sioo.core.service.config.redis.CacheUtils;
import com.sms.sioo.core.service.config.redis.RedisConstant;
import com.sms.sioo.core.service.handle.constant.RptCodeConstant;
import com.sms.sioo.core.service.pojo.RepeatInfo;
import com.sms.sioo.core.service.pojo.UserConfig;
import com.sms.sioo.core.service.pojo.UserInfo;
import org.apache.commons.lang3.StringUtils;
import org.apache.commons.lang3.time.DateUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.Arrays;
import java.util.List;

/**
 * 重号过滤校验
 *
 * @Author: creep
 * @Date: 2018/12/21 下午4:20
 */

@Service
public class RepeatMobileHandle {


    private static final Logger LOGGER = LoggerFactory.getLogger(RepeatMobileHandle.class);

    public JSONObject executeHandle(JSONObject msg, UserInfo user) {
        try {
            UserConfig userConfig = user.getUserConfig();
            if (userConfig == null) {
                return msg;
            }
            boolean result = checkRepeat(msg, userConfig);
            if (!result) {
                return msg;
            }
            msg.put("sysRptCode", RptCodeConstant.USER_REPEAT_MOBILE);
            return msg;
        } catch (Exception e) {
            LOGGER.info("RepeatMobileHandle occur error");
        }
        return null;
    }

    /**
     * 校验手机号码是否属于重号过滤
     *
     * @param msg
     * @param userConfig
     * @return false 表示未触发  true  表示出发校验
     */
    public boolean checkRepeat(JSONObject msg, UserConfig userConfig) {
        try {
            Integer filterType = userConfig.getDuplicateFilteringType();
            Integer filterTime = userConfig.getDuplicateFilteringTime();
            Integer filterAmount = userConfig.getDuplicateFilteringAmount();

            Preconditions.checkNotNull(filterType);
            Preconditions.checkNotNull(filterTime);
            Preconditions.checkNotNull(filterAmount);

            String userId = msg.getString("userId");
            String mobile = msg.getString("mobile");
            String repeatStr = CacheUtils.getString(RedisConstant.USER_REPEAT + userId + ":" + mobile);
            if (StringUtils.isBlank(repeatStr)) {
                //没有找到对应的缓存记录,则新增缓存记录
                List<Long> list = Arrays.asList(msg.getLongValue("userSubDate"));
                RepeatInfo repeatInfo = new RepeatInfo.Builder().records(list).build();
                CacheUtils.saveBean(RedisConstant.USER_REPEAT + userId + ":" + mobile, repeatInfo);
            }
            //发送记录时间戳
            RepeatInfo repeatInfo = JSON.parseObject(repeatStr, RepeatInfo.class);

            //用户提交时间
            return compareRecords(msg, repeatInfo, filterType, filterTime, filterAmount);
        } catch (Exception e) {
            LOGGER.info("RepeatMobileHandle occur error");
            return false;
        }
    }

    /**
     * 当前短信发送时间 与 发送记录进行比较
     *
     * @param msg          短信
     * @param repeatInfo   缓存信息
     * @param filterType   0：一天之内/ 1： 超过一天
     * @param filterTime   设置的时间数量
     * @param filterAmount 重复发送记录数
     * @return true代表触发   false代表未触发
     */
    public boolean compareRecords(JSONObject msg, RepeatInfo repeatInfo, int filterType, int filterTime, int filterAmount) {
        Long userSubDate = msg.getLong("userSubDate");

        List<Long> records = repeatInfo.getRecords();

        //一天之内,filterTime 存储的是分钟数,超过一天存储的天数
        if (0 == filterType) {
            long count = records.stream().filter(item -> userSubDate - item > filterTime * DateUtils.MILLIS_PER_MINUTE).count();
            //是否出发重号校验
            return count < filterAmount;
        } else {
            long count = records.stream().filter(item -> userSubDate - item > filterTime * DateUtils.MILLIS_PER_DAY).count();
            //是否出发重号校验
            return count < filterAmount;
        }
    }
}
