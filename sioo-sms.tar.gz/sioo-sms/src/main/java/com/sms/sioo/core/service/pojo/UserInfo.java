/*
 * Copyright (C) 2018 Shanghai Sioo soft Co., Ltd
 *
 * All copyrights reserved by Shanghai Sioo.
 * Any copying, transferring or any other usage is prohibited.
 * Or else, Shanghai Sioo possesses the right to require legal
 * responsibilities from the violator.
 * All third-party contributions are distributed under license by
 * Shanghai Sioo soft Co., Ltd.
 */
package com.sms.sioo.core.service.pojo;

import lombok.Getter;
import lombok.Setter;

import java.io.Serializable;

/**
 * @author xywei
 */
@Setter
@Getter
public class UserInfo implements Serializable {

    /**
     *
     */
    private static final long serialVersionUID = 1L;

    /**
     * 用户userId
     */
    private String userId;

    /**
     * 用户状态
     */
    private int enabled;

    /**
     * 租户id
     */
    private int tenantId;

    /**
     * 单价
     */
    private Double price;

    /*-----以下字段老版本-----*/

    /**
     * 接入号
     */
    private String nomber;

    /**
     * MD5 32位加密密码
     */
    private String pwd;

    /**
     * 原密码
     */
    private String dpwd;

    /**
     * 状态
     */
    private Integer stat;

    /**
     * 余额
     */
    private Float sms;

    /**
     * 优先级
     */
    private Integer priority;

    /**
     * 用户类型
     */
    private Integer userKind;

    /**
     * 企业代码
     */
    private Integer username;

    /**
     * 短信接入方式
     */
    private Integer submitType;

    /**
     * 行业类别
     */
    private Integer hyType;

    /**
     * 用户类型:1为代理,2为终端用户
     */
    private Integer userType;

    /**
     * 是否审核;1为不审核;0为审核
     */
    private Integer release;

    /**
     * 短信审核数量启始值;在isRelease为0时起作用
     */
    private Integer releaseNum;

    /**
     * 内容是否追加'回T退订',1为追加;0为不追加
     */
    private String appendTxt;

    /**
     * 签名位置;1为前置;2为后置;3为任意
     */
    private Integer signPosition;

    /**
     * 签名方式;0为强制签名;1为自定义拓展
     */
    private Integer expidSign;

    /**
     * 用户移动产品
     */
    private Integer mobile;

    /**
     * 用户联通产品
     */
    private Integer unicom;

    /**
     * 用户电信产品
     */
    private Integer telecom;

    /**
     * 用户每秒速度限制
     */
    private Integer speed;

    /**
     * 是否过滤全量黑名单0为不过滤,1为过滤
     */
    private Integer blackAll;

    /**
     * 是否记录重复签名
     */
    private Integer repeatSign;

    /**
     * 允许重复签名个数
     */
    private Integer repeatSignNum;

    /**
     * 是否开通接口状态:0为开通,1为不开通
     */
    private Integer apiRpt;

    /**
     * 每日开始发送时间
     */
    private Integer startSendTime;

    /**
     * 每日结束发送时间
     */
    private Integer endSendTime;

    /**
     * 失败自动补发次数
     */
    private Integer failResend;

    /**
     * 企业名称
     */
    private String company;


    /**
     * 用户配置
     */
    private UserConfig userConfig;

}
