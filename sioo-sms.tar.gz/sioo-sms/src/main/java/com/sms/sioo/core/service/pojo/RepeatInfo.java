package com.sms.sioo.core.service.pojo;

import lombok.Data;

import java.util.Date;
import java.util.List;

/**
 * Project:sioo-sms
 * File: com.sms.sioo.core.service.pojo
 *
 * @author : xywei
 * @date : 2019-01-16
 * Copyright 2006-2019 Sioo Co., Ltd. All rights reserved.
 */

/**
 * @author xywei
 */
@Data
public class RepeatInfo {
    /**
     * 时间戳
     */
    List<Long> records;

    private RepeatInfo(Builder builder) {
        setRecords(builder.records);
    }


    public static final class Builder {
        private List<Long> records;

        public Builder() {
        }

        public Builder records(List<Long> val) {
            records = val;
            return this;
        }

        public RepeatInfo build() {
            return new RepeatInfo(this);
        }
    }
}
