package com.sms.sioo.core.service.config.enums;

/**
 * Project:sioo-sms
 * File: com.sms.sioo.core.service.config.enums
 *
 * @author : xywei
 * @date : 2019-01-14
 * Copyright 2006-2019 Sioo Co., Ltd. All rights reserved.
 */

/**
 * 短信审核数据状态
 *
 * @author xywei
 */
public enum MsgBatchStatus {
    /**
     * 正常
     */
    NORMAL(0, "正常"),

    /**
     * 待审核
     */
    WAITVERIFY(1, "待审核"),

    /**
     * 审核通过
     */
    PASS(2, "审核通过"),

    /**
     * 审核驳回
     */
    REJECTED(3, "审核驳回");

    private int code;
    private String description;

    MsgBatchStatus(int code, String description) {
        this.code = code;
        this.description = description;
    }

    public int getCode() {
        return code;
    }

    public String getDescription() {
        return description;
    }
}
