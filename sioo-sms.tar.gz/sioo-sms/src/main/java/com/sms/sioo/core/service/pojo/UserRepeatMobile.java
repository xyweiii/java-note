package com.sms.sioo.core.service.pojo;

import lombok.Getter;
import lombok.Setter;

/**
 * 用户重号过滤
 */
@Getter
@Setter
public class UserRepeatMobile {

    private Integer userName;

    /**
     * 重号过滤;0为不过滤;1为10分钟;2为1小时;3为24小时;4为2天;5为3天;6为5天;7为7天;8为10天;9为15天;10为30天
     */
    private Integer repeatFilter;

    /**
     * 过滤数量（最大值50）只在repeat_filter大于0时
     */
    private Integer repeatNum;

}
