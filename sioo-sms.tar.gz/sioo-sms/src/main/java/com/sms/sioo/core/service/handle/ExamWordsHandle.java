package com.sms.sioo.core.service.handle;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.sms.sioo.core.service.config.redis.CacheUtils;
import com.sms.sioo.core.service.config.redis.RedisConstant;
import com.sms.sioo.core.service.handle.constant.MsgConstant;
import com.sms.sioo.core.service.handle.constant.RptCodeConstant;
import com.sms.sioo.core.service.handle.tools.DataTools;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Project:sioo-sms
 * File: com.sms.sioo.core.service.handle
 *
 * @author : xywei
 * @date : 2019-01-09
 * Copyright 2006-2019 Sioo Co., Ltd. All rights reserved.
 */

/**
 * 校验用户审核词 策略组审核词
 *
 * @author xywei
 */
@Service
public class ExamWordsHandle {

    private static final Logger LOGGER = LoggerFactory.getLogger(ExamWordsHandle.class);

    /**
     * @param msg 消息
     * @return
     */
    public JSONObject executeHandle(JSONObject msg) {
        //校验系统审核词
        matchSysExam(msg);
        //校验用户审核词
        String sysRptCode = msg.getString(MsgConstant.SYSRPTCODE);
        if (StringUtils.isNotBlank(sysRptCode)) {
            matchUserExam(msg);
        }
        return msg;
    }

    /**
     * 校验用户审核词语
     *
     * @param msg
     * @return
     */
    public JSONObject matchUserExam(JSONObject msg) {
        try {
            String sysRptCode = msg.getString(MsgConstant.SYSRPTCODE);
            if (StringUtils.isNotBlank(sysRptCode)) {
                return msg;
            }
            String userId = msg.getString("userId");
            String blackWordStr = CacheUtils.getString(RedisConstant.USER_EXAM_WORDS + userId);
            List<String> examWords = JSON.parseArray(blackWordStr, String.class);
            if (CollectionUtils.isEmpty(examWords)) {
                return msg;
            }
            for (String word : examWords) {
                //匹配词语
                String examWord = DataTools.matchWord(msg.getString("content"), word);
                if (StringUtils.isNotBlank(examWord)) {
                    msg.put("sysRptCode", RptCodeConstant.USER_STATUS_EXAM_WORD);
                    LOGGER.info("触发用户审核词; userId:{},word:{},content:{}", msg.getString("userId"), word, msg.getString("content"));
                    return msg;
                }
            }
        } catch (Exception e) {
            LOGGER.info("校验用户屏蔽词出现错误,msg：" + msg.toString());
        }
        return msg;
    }

    /**
     * 校验策略组屏蔽词
     *
     * @param msg
     * @return
     */
    public JSONObject matchSysExam(JSONObject msg) {
        try {
            String sysRptCode = msg.getString(MsgConstant.SYSRPTCODE);
            if (StringUtils.isNotBlank(sysRptCode)) {
                return msg;
            }
            String examWordStr = CacheUtils.getString(RedisConstant.SYS_STRATEGY_EXAM_WORDS + msg.get("userId"));
            if (StringUtils.isBlank(examWordStr)) {
                LOGGER.info("系统审核词为空,userId:" + msg.getString("userId"));
                return msg;
            }
            List<String> examWords = JSON.parseArray(examWordStr, String.class);
            if (CollectionUtils.isEmpty(examWords)) {
                return msg;
            }
            for (String word : examWords) {
                String examWord = DataTools.matchWord(msg.getString("content"), word);
                if (StringUtils.isNotBlank(examWord)) {
                    msg.put("sysRptCode", RptCodeConstant.SYS_STATUS_EXAM_WORD);
                    LOGGER.info("触发系统审核词; userId:{},word:{},content:{}", msg.getString("userId"), word, msg.getString("content"));
                    return msg;
                }
            }
        } catch (Exception e) {
            LOGGER.info("校验系统审核词出现错误,msg：" + msg.toString());
        }
        return msg;
    }

}