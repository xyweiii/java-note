package com.sms.sioo.core.service.pojo;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
/**
 * 产品明细
 */
public class ProductDetail {

    /**
     * 通道ID
     */
    private Integer channelId;

    /**
     * 权重
     */
    private Integer weight;

    /**
     * 产品ID
     */
    private Integer productId;
}
