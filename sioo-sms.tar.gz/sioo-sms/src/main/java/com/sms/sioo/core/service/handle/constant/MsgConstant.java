package com.sms.sioo.core.service.handle.constant;

import scala.Int;

/**
 * @Author: creep
 * @Date: 2018/12/25 下午2:08
 */
public class MsgConstant {


    /**
     * 用户 userId (String)
     */
    public static final String USERID = "userId";

    /**
     * 用户余额 (double)
     */
    public static final String PRICE = "price";

    /**
     * 租户Id (String)
     */
    public static final String TENANTID = "tenantId";

    /**
     * 信息来源  (int)  0:api接口数据  1:Web数据
     */
    public static final String SOURCE = "source";

    /**
     * 是否是模板 (boolean)
     */
    public static final String TEMPLATE = "template";

    /**
     * 触发审核标志 boolean类型数据
     */
    public static final String RELEASE = "release";

    /**
     * 号码类型 mtype  (int)
     */
    public static final String MTYPE = "mtype";


    /**
     * 用户是否开通接口状态:0为开通,1为不开通
     */
    public static final String APIRPT = "apiRpt";

    /**
     * 短信内容
     */
    public static final String CONTENT = "content";

    /**
     * 内容条数
     */
    public static final String CONTENT_NUM = "contentNum";

    /**
     * 重号过滤 (boolean)
     */
    public static final String REPEAT_MOBILE = "repeat";

    /**
     * 通道组产品id (String)
     */
    public static final String CHANNEL_GROUPID = "channelGroupId";

    /**
     * 通道id (String)
     */
    public static final String CHANNELID = "channelId";

    /**
     * 签名
     */
    public static final String SIGN = "sign";

    /**
     * 签名拓展码
     */
    public static final String EXTNO = "extNo";

    /**
     * 系统校验错误码sysRptCode
     */
    public static final String SYSRPTCODE = "sysRptCode";
}
