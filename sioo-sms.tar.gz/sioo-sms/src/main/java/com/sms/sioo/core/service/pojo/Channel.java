/*
 * Copyright (C) 2018 Shanghai Sioo soft Co., Ltd
 *
 * All copyrights reserved by Shanghai Sioo.
 * Any copying, transferring or any other usage is prohibited.
 * Or else, Shanghai Sioo possesses the right to require legal
 * responsibilities from the violator.
 * All third-party contributions are distributed under license by
 * Shanghai Sioo soft Co., Ltd.
 */
package com.sms.sioo.core.service.pojo;

import lombok.Getter;
import lombok.Setter;

/**
 * @author sioo
 */
@Getter
@Setter
public class Channel {

    private String id;

    /**
     * 接入方式 1为cmpp,2为sgip,3为smgp,4为http
     */
    private int type;
    /**
     * 通道名称
     */
    private String channelName;

    /**
     * 通道支持网络(1为全网,2为移动,3为联通,5为电信)
     */
    private Integer supportNetwork;

    /**
     * 通道支持单条字数(默认70)
     */
    private Integer sendWordsLen;

    /**
     * 通道支持最大字数(默认500)
     */
    private Integer sendWordsMaxlen;

    /**
     * 报备方式(0为无,1为先报备后发,2为先发后报备)
     */
    private Integer recordType;

    /**
     * 路由类型(0为无路由,1为关键词路由,2为验证码路由,3为通知路由,4为营销路由)
     */
    private Integer routeType;

    /**
     * 路由条件,结合route_type使用
     */
    private String routeRequire;

    /**
     * 触发路由条件后走的通道
     */
    private Integer routeChannel;

    /**
     * 签名位置(0为任意,1为前置,2为后置)
     */
    private Integer signPosition;

    /**
     * 通道是否支持双签名;0为支持,1为不支持
     */
    private Integer isSigns;

    /**
     * 通道状态0为正常,1为暂停,2为停止
     */
    private Integer status;

    /**
     * 通道速率
     */
    private Integer sendRate;

}
