package com.sms.sioo.core.service.pojo;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
/**
 * 系统白名单
 */
public class SysWhiteMobile {

    /**
     * 号码
     */
    private Long mobile;

    /**
     * 组ID
     */
    private Integer groupId;

    private Integer cid;


}
