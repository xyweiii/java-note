package com.sms.sioo.core.service.config.redis;

/**
 * @Author: creep
 * @Date: 2018/12/17 下午5:13
 */
public class RedisConstant {


    /**
     * 用户信息key prefix + userId
     */
    public static final String USER_INFO_USERID = "user_info_userId:";

    /**
     * 用户模板信息 key : pre + userId
     */
    public static final String USER_TEMPLATE = "user_template:";

    /**
     * 通道产品组和通道关联信息
     * key: prefix + channelGroupId + tenantId
     * value: 该通道产品组对应的多个通道id List<String>
     */
    public static final String CHANNEL_GROUP_RELATION_INFO = "channel_group_relation_info";

    /**
     * 通道信息key prefix + channelId
     * <p>
     * channel
     */
    public static final String CHANNEL_INFO = "channel_info:";


    /**
     * 通道产品组信息
     * key: prefix + channelGroupId,
     * value: 该通道产品组对应的多个通道信息 List<Channel>
     */
    // TODO: 2019/1/17 多余的，需要删除
    public static final String CHANNEL_GROUP_INFO = "channel_group_info";

    /**
     * 用户白名单 key: prefix + userId
     * <p>
     * String
     */
    public static final String USER_WHITE_MOBILE = "user_white_mobile:";

    /**
     * 用户黑名单 key: prefix + userId
     * <p>
     * String
     */
    public static final String USER_BLACK_MOBILE = "user_black_mobile:";

    /**
     * 用户屏蔽词 key: prefix + userId
     * <p>
     * List<String>
     */
    public static final String USER_BLACK_WORDS = "user_black_words:";

    /**
     * 系统策略组屏蔽词 key: prefix
     * <p>
     * List<String>
     */
    public static final String SYS_STRATEGY_BLACK_WORDS = "sys_black_words:";

    /**
     * 用户审核词 key: prefix + userId
     * <p>
     * List<String>
     */
    public static final String USER_EXAM_WORDS = "user_exam_words:";

    /**
     * 系统策略审核词 key: prefix
     * <p>
     * List<String>
     */
    public static final String SYS_STRATEGY_EXAM_WORDS = "sys_exam_words:";

    /**
     * 用户签名key prefix + userId (多个签名String)
     * List<Signature>
     */
    public static final String USER_SIGNATURE_INFO = "user_signature_info:";


    /**
     * 钓鱼号码
     */
    public static final String FISH_MOBILE = "fish_mobile:";

    /**
     * 重号过滤
     * key + userId +":" + mobile
     */
    public static final String USER_REPEAT = "user_repeat:";


    /**
     * 用户屏蔽地区
     * pre +":" +provinceCode + ":" + cityCode + ":" + userId
     */
    public static final String USER_BLACK_AREA = "user_black_area:";

    /**
     * 通道屏蔽地区
     * pre +":" + provinceCode + ":" +cityCode +":" + channelId
     */
    public static final String CHANNEL_BLACK_AREA = "channel_black_area:";


    /**
     * 短信批次号
     * <p>
     * key + batchId
     */
    public static final String SMS_MSG_BATCHID = "sms_msg_batchId:";




    /*-----------下面老字段,暂时用不上-----------*/

    /**
     * 用户余额key prefix + userId
     */
    public static final String USER_BALANCE = "user_balance:";

    /**
     * 用户签名key prefix + userId + channel
     */
    public static final String USER_CHANNEL_SIGNATURE_INFO = "user_signature_info:";

    /**
     * 用户签名拓展key prefix + userId + singature
     */
    public static final String USER_SIGNATURE_EXTENSION = "user_signature:";

    /**
     * 用户屏蔽词key prefix + userId
     */
    public static final String USER_SHIELDING_WORDS = "user_shielding_words:";

    /**
     * 用户策略key prefix + userId
     */
    public static final String USER_STRATEGY = "user_strategy:";

    /**
     * 用户审核词key prefix + userId
     */
    public static final String USER_EXAMINE_WORDS = "user_examine_words:";

    /**
     * 用户屏蔽地区key prefix + userId
     */
    public static final String USER_SCREENED_AREA = "user_screened_area:";

    /**
     * 用户重号过滤配置key prefix + userId
     */
    public static final String USER_DUPLICATE_FILTER = "user_duplicate_filter:";

    /**
     * 系统白名单
     */
    public static final String SYS_WHITE_MOBILE = "sys_white_mobile:";

    /**
     * 系统屏蔽词
     */
    public static final String SYS_SHIELDING_WORDS = "user_shielding_words:";

    /**
     * 系统审核词
     */
    public static final String SYS_EXAMINE_WORDS = "sys_examine_words:";
}
