package com.sms.sioo.core.service;

import com.sms.sioo.core.service.handle.eventbus.BatchFailObserver;
import com.sms.sioo.core.service.handle.eventbus.EventBusCenter;
import org.apache.commons.daemon.Daemon;
import org.apache.commons.daemon.DaemonContext;
import org.apache.commons.daemon.DaemonInitException;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;


public class Boot implements Daemon {

    private static final Logger logger = LoggerFactory.getLogger(Boot.class);

    public volatile boolean shutdown = false;

    public static void main(String[] args) {

        logger.info("start sioo-sms ...");
        Boot boot = new Boot();
        try {
            BatchFailObserver batchFailObserver = new BatchFailObserver();
            EventBusCenter.register(batchFailObserver);
            boot.start();
            while (true) {
                Thread.sleep(1000);
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        logger.info("sioo-sms stopped ...");
    }

    @Override
    public void init(DaemonContext daemonContext) throws DaemonInitException, Exception {

    }

    @Override
    public void start() throws Exception {
        SiooSmsApplication.main(new String[]{});
    }

    @Override
    public void stop() throws Exception {
        logger.info(String.format("Stop sioo-sms server ......."));

    }

    @Override
    public void destroy() {
        try {
            stop();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }
}
