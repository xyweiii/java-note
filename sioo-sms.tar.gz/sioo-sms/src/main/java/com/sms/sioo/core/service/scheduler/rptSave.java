/*
package com.sms.sioo.core.service.scheduler;

import com.alibaba.fastjson.JSONObject;
import com.sms.sioo.core.service.dao.ManagerBaseDao;
import com.sms.sioo.core.service.utils.SmsCache;
import com.sms.sioo.core.service.utils.SmsTaskQueue;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.datasource.DataSourceUtils;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

*/
/**
 * 状态入库
 *//*

public class rptSave implements Runnable {

    private static final Logger LOG = LoggerFactory.getLogger(rptSave.class);

    List<JSONObject> list = new ArrayList<>();

    private ManagerBaseDao managerDao;

    public rptSave(ManagerBaseDao managerDao){
        this.managerDao = managerDao;
    }


    */
/**
     * When an object implementing interface <code>Runnable</code> is used
     * to create a thread, starting the thread causes the object's
     * <code>run</code> method to be called in that separately executing
     * thread.
     * <p>
     * The general contract of the method <code>run</code> is that it may
     * take any action whatsoever.
     *
     * @see Thread#run()
     *//*

    @Override
    public void run() {
        while (true){
            try {
                int count = SmsTaskQueue.INSERT_STATUS_QUEUE.drainTo(list, 3000);
                if(count > 0){
                    try{
                        long l = System.currentTimeMillis();
                        Connection conn = DataSourceUtils.getConnection(managerDao.getSqlSession().getConfiguration().getEnvironment().getDataSource());
                        conn.setAutoCommit(false);
                        PreparedStatement insert = conn.prepareStatement("INSERT INTO sms_rpt_dtl(username,cid,mobile,rptcode,unique_id,batch_id,rpt_time,channel_id,extno,resend_max,resend_count,user_sub_time,channel_sub_time,resend,price)VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?);");

                        for(JSONObject obj : list){
                            try {
                                insert.setInt(1,obj.getIntValue("userName"));
                                insert.setInt(2,obj.getIntValue("cid"));
                                insert.setLong(3,obj.getLongValue("mobile"));
                                insert.setString(4,obj.getString("rptCode"));
                                insert.setLong(5,obj.getLongValue("uniqueId"));
                                insert.setLong(6,obj.getLongValue("batchId"));
                                insert.setLong(7,obj.getLongValue("rptTime"));
                                insert.setInt(8,obj.getIntValue("channelId"));
                                insert.setString(9,obj.getString("extno"));
                                insert.setInt(10,obj.getIntValue("resendMax"));
                                insert.setInt(11,obj.getIntValue("resendCount"));
                                insert.setLong(12,obj.getLongValue("userSubTime"));
                                insert.setLong(13,obj.getLongValue("channelSubTime"));
                                insert.setInt(14,0);
                                insert.setDouble(15,obj.getDoubleValue("price"));
                                insert.addBatch();
                            } catch (SQLException e) {
                                LOG.error(e.getMessage(),e);
                            }
                        }
                        insert.executeBatch();
                        conn.commit();
                        insert.close();
                        DataSourceUtils.releaseConnection(conn,managerDao.getSqlSession().getConfiguration().getEnvironment().getDataSource());
                        LOG.info("batch insert rpt size["+count+"]-time-consuming:"+(System.currentTimeMillis()-l));
                    }catch(Exception e){
                        LOG.error(e.getMessage(),e);
                    }finally {
                        list.clear();
                    }
                }
            } catch (Exception e) {
                LOG.error(e.getMessage(),e);
            }
            try {
                Thread.sleep(200);
            } catch (InterruptedException e) {
            }
        }
    }
}
*/
