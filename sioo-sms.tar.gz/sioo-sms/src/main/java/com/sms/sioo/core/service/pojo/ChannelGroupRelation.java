package com.sms.sioo.core.service.pojo;

/**
 * Project:sioo-sms
 * File: com.sms.sioo.core.service.pojo
 *
 * @author : xywei
 * @date : 2019-01-08
 * Copyright 2006-2019 Sioo Co., Ltd. All rights reserved.
 */
public class ChannelGroupRelation {


    private String id;

    /**
     * 通道组Id
     */
    private String groupId;

    /**
     * 通道Id
     */
    private String channenId;

    /**
     * 租户id
     */
    private String tenantId;

}
