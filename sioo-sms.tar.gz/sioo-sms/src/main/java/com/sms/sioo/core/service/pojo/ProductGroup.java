package com.sms.sioo.core.service.pojo;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
/**
 * 产品组
 */
public class ProductGroup {

    private Integer id;

    /**
     * 产品名称
     */
    private String productName;
}
