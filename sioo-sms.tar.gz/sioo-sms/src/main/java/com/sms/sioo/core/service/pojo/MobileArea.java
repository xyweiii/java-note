package com.sms.sioo.core.service.pojo;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
public class MobileArea {

    /**
     * 号段(号码前7位)
     */
    private Integer number;

    /**
     * 省名称
     */
    private String province;

    /**
     * 市名称
     */
    private String city;

    /**
     * 运营商编号(1移动,2联通,4电信)
     */
    private Integer type;

    /**
     * 运营商名称
     */
    private String typeDesc;

    /**
     * 省编号
     */
    private Integer provinceCode;

    /**
     * 市编号
     */
    private Integer cityCode;
}
