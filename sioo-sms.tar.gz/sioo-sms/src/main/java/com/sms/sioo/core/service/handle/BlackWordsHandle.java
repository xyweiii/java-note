package com.sms.sioo.core.service.handle;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.sms.sioo.core.service.config.redis.CacheUtils;
import com.sms.sioo.core.service.config.redis.RedisConstant;
import com.sms.sioo.core.service.handle.constant.RptCodeConstant;
import com.sms.sioo.core.service.handle.tools.DataTools;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.List;

/**
 * Project:sioo-sms
 * File: com.sms.sioo.core.service.handle
 *
 * @author : xywei
 * @date : 2019-01-09
 * Copyright 2006-2019 Sioo Co., Ltd. All rights reserved.
 */


/**
 * 用户屏蔽词,策略组屏蔽词
 */

@Service
public class BlackWordsHandle {

    private static final Logger LOGGER = LoggerFactory.getLogger(BlackWordsHandle.class);

    /**
     * @param msg 消息
     * @return
     */
    public JSONObject executeHandle(JSONObject msg) {
        //校验用户屏蔽词
        matchUserBlack(msg);
        //校验策略组屏蔽词
        matchStrategyBlack(msg);
        return msg;
    }

    /**
     * 校验策略屏蔽词
     *
     * @param msg
     * @return
     */
    public JSONObject matchUserBlack(JSONObject msg) {
        try {
            String sysRptCode = msg.getString("sysRptCode");
            if (StringUtils.isNotBlank(sysRptCode)) {
                return msg;
            }
            String userId = msg.getString("userId");
            String blackWordStr = CacheUtils.getString(RedisConstant.USER_BLACK_WORDS + userId);
            List<String> blackWords = JSON.parseArray(blackWordStr, String.class);
            if (CollectionUtils.isEmpty(blackWords)) {
                return msg;
            }
            for (String word : blackWords) {
                String blackWord = DataTools.matchWord(msg.getString("content"), word);
                if (StringUtils.isNotBlank(blackWord)) {
                    msg.put("sysRptCode", RptCodeConstant.USER_STATUS_BLACK_WORD);
                    LOGGER.info("触发用户屏蔽词; userId:{},words:{},content:{}", userId, word, msg.getString("content"));
                    return msg;
                }
            }
        } catch (Exception e) {
            LOGGER.info("校验用户屏蔽词出现错误,msg：" + msg.toString());
        }
        return msg;
    }

    /**
     * 校验策略组屏蔽词
     *
     * @param msg
     * @return
     */
    public JSONObject matchStrategyBlack(JSONObject msg) {
        try {
            String sysRptCode = msg.getString("sysRptCode");
            if (StringUtils.isNotBlank(sysRptCode)) {
                return msg;
            }
            String strategyWordStr = CacheUtils.getString(RedisConstant.SYS_STRATEGY_BLACK_WORDS + msg.get("userId"));
            if (StringUtils.isBlank(strategyWordStr)) {
                LOGGER.info("系统屏蔽词为空,userId:" + msg.getString("userId"));
                return msg;
            }
            List<String> strategyWords = JSON.parseArray(strategyWordStr, String.class);
            if (CollectionUtils.isEmpty(strategyWords)) {
                return msg;
            }
            for (String word : strategyWords) {
                //校验词语匹配
                String blackWord = DataTools.matchWord(msg.getString("content"), word);
                if (StringUtils.isNotBlank(blackWord)) {
                    msg.put("sysRptCode", RptCodeConstant.SYS_STATUS_STRATEGY_WORD);
                    LOGGER.info("触发系统屏蔽词; userId:{},word:{},content:{}", msg.getInteger("userId"), word, msg.getString("content"));
                    return msg;
                }
            }
        } catch (Exception e) {
            LOGGER.info("校验系统屏蔽词出现错误,msg：" + msg.toString());
        }
        return msg;
    }
}