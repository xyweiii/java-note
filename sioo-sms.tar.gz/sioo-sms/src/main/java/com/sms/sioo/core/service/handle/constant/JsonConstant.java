package com.sms.sioo.core.service.handle.constant;

/**
 * @Author: creep
 * @Date: 2018/12/25 下午2:08
 */
public class JsonConstant {

    /**
     * 标记是否为批次失败 1为批次失败否则为单条失败
     */
    public static final String FAIL_KEY="batchFail";

    /**
     * 状态code
     */
    public static final String RESPONSE_CODE_KEY="rptCode";

    /**
     * 内容条数
     */
    public static final String CONTENT_NUM="contentNum";


}
