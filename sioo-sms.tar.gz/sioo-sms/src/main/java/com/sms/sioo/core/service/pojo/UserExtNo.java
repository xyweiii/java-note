package com.sms.sioo.core.service.pojo;

import lombok.Getter;
import lombok.Setter;

/**
 * 用户签名表
 */
@Getter
@Setter
public class UserExtNo {

    /**
     * 用户名
     */
    private Integer userName;

    /**
     * 拓展号
     */
    private String extno;

    /**
     * 签名
     */
    private String sign;

    /**
     * 是否默认（0为不默认，1为默认）
     */
    private Integer isDefault;

}
