package com.sms.sioo.core.service.scheduler;

import com.alibaba.fastjson.JSONObject;
import com.sms.sioo.core.service.config.redis.CacheUtils;
import com.sms.sioo.core.service.utils.SmsCache;
import com.sms.sioo.core.service.utils.SmsTaskQueue;
import org.apache.commons.collections.CollectionUtils;
import org.bson.Document;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

/**
 * 批次信息入库到MongoDB
 */
public class MsgBatchSave implements Runnable {

    private static final Logger LOG = LoggerFactory.getLogger(MsgBatchSave.class);

    private MongoTemplate mongoTemplate;

    public MsgBatchSave(MongoTemplate mongoTemplate) {
        this.mongoTemplate = mongoTemplate;
    }


    /**
     * When an object implementing interface <code>Runnable</code> is used
     * to create a thread, starting the thread causes the object's
     * <code>run</code> method to be called in that separately executing
     * thread.
     * <p>
     * The general contract of the method <code>run</code> is that it may
     * take any action whatsoever.
     *
     * @see Thread#run()
     */
    @Override
    public void run() {
        while (true) {
            try {
                long l = System.currentTimeMillis();
                List<JSONObject> list = new ArrayList<>();
                int count = SmsTaskQueue.SAVE_BATCH_QUEUE.drainTo(list, 5000);
                if (count > 0) {
                    try {
                        List<Document> insertList = new ArrayList<>();
                        Map<Long, JSONObject> map = new HashMap<>();
                        for (JSONObject obj : list) {
                            if (!map.containsKey(obj.getLongValue("batchId"))) {
                                map.put(obj.getLongValue("batchId"), obj);
                                continue;
                            }
                            JSONObject o = map.get(obj.getLongValue("batchId"));
                            o.put("mobiles", o.getIntValue("mobiles") + obj.getIntValue("mobiles"));
                        }
                        Map<Long, Integer> map1 = new HashMap<>();
                        for (Map.Entry<Long, JSONObject> entry : map.entrySet()) {
                            if (CacheUtils.isCached("bh_" + entry.getKey())) {
                                map1.put(entry.getKey(), entry.getValue().getIntValue("mobiles"));
                                continue;
                            }
                            CacheUtils.saveString("bh_" + entry.getKey(), "", 24 * 3600);
                            JSONObject obj = entry.getValue();
                            Document cument = new Document();
                            cument.put("submitTime", obj.getLongValue("senddate"));
                            cument.put("cid", obj.getIntValue("cid"));
                            cument.put("userName", obj.getIntValue("userName"));
                            cument.put("content", obj.getString("content"));
                            cument.put("contentNum", obj.getIntValue("contentNum"));
                            cument.put("batchId", obj.getLongValue("batchId"));
                            cument.put("mobiles", obj.getIntValue("mobiles"));
                            cument.put("succ", obj.getIntValue("succ"));
                            cument.put("fail", obj.getIntValue("fail"));
                            insertList.add(cument);
                        }
                        if (CollectionUtils.isNotEmpty(insertList)) {
                            mongoTemplate.getCollection("sms_msg_batch").insertMany(insertList);
                        }
                        for (Map.Entry<Long, Integer> entry : map1.entrySet()) {
                            Update update = new Update();
                            update.inc("mobiles", entry.getValue());
                            mongoTemplate.updateMulti(new Query(Criteria.where("batchId").is(entry.getKey())), update, "sms_msg_batch");
                        }
                    } catch (Exception e) {
                        LOG.error(e.getMessage(), e);
                    } finally {
                        list.clear();
                    }
                    LOG.info("batch handle msg size[" + count + "]-time-consuming:" + (System.currentTimeMillis() - l));
                }
            } catch (Exception e) {
                LOG.error(e.getMessage(), e);
            }
            try {
                Thread.sleep(200);
            } catch (InterruptedException e) {
            }
        }
    }
}
