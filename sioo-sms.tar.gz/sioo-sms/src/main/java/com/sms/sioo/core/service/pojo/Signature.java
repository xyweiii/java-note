package com.sms.sioo.core.service.pojo;

/**
 * Project:sioo-sms
 * File: com.sms.sioo.core.service.pojo
 *
 * @author : xywei
 * @date : 2019-01-08
 * Copyright 2006-2019 Sioo Co., Ltd. All rights reserved.
 */

import lombok.Data;

import java.util.Date;

/**
 * 通道信息
 *
 * @author xywei
 */

@Data
public class Signature {

    /**
     * tenantId
     */
    private String tenantId;

    /**
     * 用户名
     */
    private String username;

    /**
     * 签名
     */
    private String signature;

    /**
     * 用户拓展
     */
    private String userExtension;

    /**
     * 通道id
     */
    private String channelId;

    /**
     * 通道拓展
     */
    private String channelExtension;

    /**
     * 签名状态：0未审核 1已通过 2已报备 3已驳回
     */
    private Integer status;

    /**
     * 是否删除: 0:未删除,1:已删除
     */
    private String deleted;

    /**
     * 是否拉黑： 0:未拉黑,1:已拉黑
     */
    private String defriend;

    /**
     * 申请时间
     */
    private Date applyDate;

    /**
     * 报备时间
     */
    private Date reportDate;

}
