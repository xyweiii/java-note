package com.sms.sioo.core.service.repository.data;

import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.Date;

/**
 * Project:sioo-sms
 * File: com.sms.sioo.core.service.repository.data
 *
 * @author : xywei
 * @date : 2019-01-11
 * Copyright 2006-2019 Sioo Co., Ltd. All rights reserved.
 */

/**
 * 短信批次表
 *
 * @author xywei
 */
@Document(collection = "sms_msg_batch")
@Data
public class MsgBatchData {

    @Id
    private String id;

    /**
     * 用户id
     */
    private String userId;

    /**
     * 租户id
     */
    private String tenantId;

    /**
     * 批次id
     */
    private Long batchId;

    /**
     * 唯一id
     */
    private Long uniqueId;

    /**
     * 内容
     */
    private String content;

    /**
     * 内容数量
     */
    private Integer contentNum;

    /**
     * 手机号数量
     */
    private Integer mobileNum;

    /**
     * 是否模板
     */
    private boolean template = false;

    /**
     * 是否出发审核
     */
    private boolean release = false;

    /**
     * 校验码
     */
    private String sysRptCode;

    /**
     * 提交时间
     */
    private Long userSubDate;

    /**
     * 提交成功数
     */
    private Integer submitSuccessNum;

    /**
     * 提交失败数
     */
    private Integer submitFailNum;

    /**
     * 回执成功数
     */
    private Integer deliverSuccessNum;

    /**
     * 回执失败数
     */
    private Integer deliverFailNum;

    /**
     * 创建时间
     */
    private Date createDate = new Date();

    /**
     * 更新时间
     */
    private Date updateDate = new Date();

}
