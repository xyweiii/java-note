package com.sms.sioo.core.service.handle;

import com.alibaba.fastjson.JSONObject;
import com.sms.sioo.core.service.config.redis.CacheUtils;
import com.sms.sioo.core.service.config.redis.RedisConstant;
import com.sms.sioo.core.service.handle.constant.MsgConstant;
import com.sms.sioo.core.service.pojo.UserInfo;
import com.sms.sioo.core.service.utils.SmsTaskQueue;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.concurrent.CompletableFuture;

/**
 * @Author: creep
 * @Date: 2018/12/17 下午2:24
 */
@Service
public class SmsService {

    private static final Logger LOGGER = LoggerFactory.getLogger(SmsService.class);

    @Autowired
    private PrepareHandle prepareHandle;

    @Autowired
    private CoreHandle coreHandle;

    @Autowired
    private TemplateHandle templateHandle;

    @Autowired
    private BlackWordsHandle blackWordsHandle;

    @Autowired
    private ExamWordsHandle examWordsHandle;

    /**
     * type: 1为CMPP优先队列，2为CMPP普通队列，3为CMPP营销队列，4为HTTP优先队列，5为HTTP普通队列，6为HTTP营销队列）
     */
    public void smsHandle(int type, JSONObject msg) {
        try {

            String userId = msg.getString("userId");
            //校验用户是否存在
            UserInfo user = CacheUtils.getBean(RedisConstant.USER_INFO_USERID + userId, UserInfo.class);
            if (user == null) {
                LOGGER.info("用户不存在,userId:" + userId);
                return;
            }
            if (user.getEnabled() == 0) {
                LOGGER.info("用户状态处于禁用状态,userId:" + userId);
                return;
            }
            //模板校验,屏蔽词校验, 审核词校验
            CompletableFuture<JSONObject> future = CompletableFuture.supplyAsync(() -> prepareHandle.executeHandle(msg, type, user))
                    .thenApplyAsync(templateHandle::executeHandle)
                    .thenApplyAsync(blackWordsHandle::executeHandle)
                    .thenApplyAsync(examWordsHandle::executeHandle);

            JSONObject result = future.get();
            //保存批次信息
            if (result.getBoolean(MsgConstant.RELEASE)) {
                //审核队列
                SmsTaskQueue.SAVE_VERIFY_QUEUE.add(msg);
            }
            //批次信息
            SmsTaskQueue.SAVE_BATCH_QUEUE.add(msg);
            //拆分数据 校验
            CompletableFuture.supplyAsync(() -> coreHandle.executeHandle(result, user));
        } catch (Exception e) {
            LOGGER.error("smsHandle校验发生异常,msg=" + msg.toString());
        }
    }
}
