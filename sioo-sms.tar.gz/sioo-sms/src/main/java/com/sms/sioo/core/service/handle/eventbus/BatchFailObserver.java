package com.sms.sioo.core.service.handle.eventbus;

import com.alibaba.fastjson.JSONObject;
import com.google.common.eventbus.Subscribe;
import com.sms.sioo.core.service.handle.UserPropertyHandle;
import com.sms.sioo.core.service.handle.tools.DataTools;
import com.sms.sioo.core.service.pojo.UserInfo;
import com.sms.sioo.core.service.utils.SmsCache;
import com.sms.sioo.core.service.utils.SmsTaskQueue;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.core.AmqpTemplate;
import org.springframework.beans.factory.annotation.Autowired;

import java.util.List;

/**
 * @Author: creep
 * @Date: 2018/12/24 下午6:16
 */
public class BatchFailObserver {

    private static final Logger logger = LoggerFactory.getLogger(BatchFailObserver.class);

    @Autowired
    private AmqpTemplate rabbitTemplate;

    public UserPropertyHandle userPropertyHandle;

    /**
     * @Description: 批次失败处理
     * @param: [type, obj]
     * @return: void
     * @author: creep
     * @Time: 2018/12/24 下午2:36
     */
    @Subscribe
    public void batchFail(JSONObject obj) {
        //根据标识判断是走批次失败还是单条失败

        String[] ms = obj.getString("mobile").split(",");
        int count = ms.length * obj.getInteger("contentNum");
        /*
         * 计费 ：
         *
         *      if(余额足够){
         *       根据当前批次数据量>1 生成订单交易表(trade_order) 和流水表(balance_log) 否则 直接走下面流程
                 mysql 用户余额 update

         *      }
         *       MongoDB： 批次信息 sms_msg_batch ，详情 sms_msg_dtl
                 mysql ：状态表 sms_rpt_dtl 所有状态更新
         *
         */

        List<JSONObject> list = DataTools.convert(obj);
        for (JSONObject o : list) {
            fail(o);
        }
    }

    /**
     * @Description:
     * @param: [o]
     * @return: void
     * @author: creep
     * @Time: 2018/12/24 下午2:37
     */
    public void fail(JSONObject o) {
        try {
            UserInfo user = SmsCache.USERINFO.get(o.getInteger("userName"));
            userPropertyHandle.updateProperty(o, user);
            for (int i = 0; i < o.getInteger("contentNum"); i++) {
                JSONObject rpt = new JSONObject();
                rpt.put("userName", user.getUsername());
                //rpt.put("cid", user.getCid());
                rpt.put("mobile", o.getLong("mobile"));
                rpt.put("rptCode", o.getString("rptCode"));
                rpt.put("uniqueId", o.getLong("uniqueId"));
                rpt.put("batchId", o.getLong("batchId"));
                rpt.put("rptTime", System.currentTimeMillis());
                rpt.put("channelId", o.getInteger("channelId"));
                rpt.put("extno", o.getString("extno"));
                rpt.put("resendMax", 0);
                rpt.put("resendCount", 0);
                rpt.put("userSubTime", o.getLong("senddate"));
                rpt.put("channelSubTime", 0);
                rpt.put("price", o.getDoubleValue("price"));
                if (user.getApiRpt() == 0) {
                    if (user.getSubmitType() == 1) {
                        rabbitTemplate.convertAndSend("sms.push", "push.cmpp.state", rpt);
                    } else {
                        rabbitTemplate.convertAndSend("sms.push", "push.http.state", rpt);
                    }
                }
                SmsTaskQueue.UPDATE_BATCH_QUEUE.add(rpt);
                SmsTaskQueue.INSERT_STATUS_QUEUE.add(rpt);
            }
            o.put("subSucc", o.getInteger("contentNum"));
            o.put("subFail", 0);
            o.put("rptSucc", 0);
            o.put("rptFail", o.getInteger("contentNum"));
            o.put("location", o.getString("location").split(",")[0]);
            SmsTaskQueue.SAVE_DTL_QUEUE.add(o);
        } catch (NumberFormatException e) {
            logger.error(e.getMessage(), e);
        }
    }





}
