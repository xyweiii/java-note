package com.sms.sioo.core.service.scheduler;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.google.common.collect.Lists;
import com.sms.sioo.core.service.config.redis.CacheUtils;
import com.sms.sioo.core.service.config.redis.RedisConstant;
import com.sms.sioo.core.service.repository.data.MsgBatchData;
import com.sms.sioo.core.service.utils.SmsTaskQueue;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.data.mongodb.core.query.Criteria;
import org.springframework.data.mongodb.core.query.Query;
import org.springframework.data.mongodb.core.query.Update;
import org.springframework.stereotype.Component;

import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;

/**
 * 存储短信批次信息
 *
 * @author xywei
 */
@Component
public class MsgBatchHandle implements Runnable, InitializingBean {

    public static final Logger LOGGER = LoggerFactory.getLogger(MsgBatchHandle.class);

    @Autowired
    private MongoTemplate mongoTemplate;

    private static final List<JSONObject> msgBatchList = Lists.newArrayList();

    @Override
    public void run() {
        try {
            while (true) {
                int count = SmsTaskQueue.SAVE_BATCH_QUEUE.drainTo(msgBatchList, 1000);
                if (count > 0) {
                    msgBatchList.parallelStream().forEach(item -> {
                        Criteria criteria = Criteria.where("batchId").is(item.getString("batchId"));
                        boolean isCached = CacheUtils.isCached(RedisConstant.SMS_MSG_BATCHID + item.getString("batchId"));
                        //新增或删除
                        if (isCached) {
                            MsgBatchData msgBatchData = JSON.parseObject(item.toJSONString(), MsgBatchData.class);
                            mongoTemplate.insert(msgBatchData);
                        } else {
                            Update update = Update.update("updateDate", new Date())
                                    .inc("mobileNum", item.getIntValue("mobileNum"));
                            mongoTemplate.updateFirst(new Query().addCriteria(criteria), update, MsgBatchData.class);
                        }
                    });
                } else {
                    TimeUnit.MILLISECONDS.sleep(1000);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            LOGGER.error(" MsgBatchHandle occur error,msg:" + e.getMessage());
        }
    }

    @Override
    public void afterPropertiesSet() {
        new Thread(this).start();
    }

}
