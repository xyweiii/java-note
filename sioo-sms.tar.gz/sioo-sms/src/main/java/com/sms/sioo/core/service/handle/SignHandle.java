package com.sms.sioo.core.service.handle;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.google.common.collect.Lists;
import com.sms.sioo.core.service.config.enums.ChannelRecordType;
import com.sms.sioo.core.service.config.enums.ChannelStatus;
import com.sms.sioo.core.service.config.redis.CacheUtils;
import com.sms.sioo.core.service.config.redis.RedisConstant;
import com.sms.sioo.core.service.handle.constant.RptCodeConstant;
import com.sms.sioo.core.service.pojo.Channel;
import com.sms.sioo.core.service.pojo.Signature;
import com.sms.sioo.core.service.pojo.UserInfo;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.*;
import java.util.stream.Collectors;

/**
 * 校验签名和拓展
 *
 * @Author: creep
 * @Date: 2018/12/24 下午2:19
 */
@Service
public class SignHandle {

    private static final String SIGN_PREFIX = "【";
    private static final String SIGN_SUFFIX = "】";


    private static final Logger LOGGER = LoggerFactory.getLogger(SignHandle.class);

    public JSONObject executeHandle(JSONObject msg) {
        try {
            String sysRptCode = msg.getString("sysRptCode");
            //rptCode不为空,无需校验
            if (StringUtils.isNotBlank(sysRptCode)) {
                return msg;
            }
            String sign;
            String content = msg.getString("content");
            //签名 开头/结尾
            if (StringUtils.startsWith(content, SIGN_PREFIX)) {
                sign = content.substring(0, content.indexOf(SIGN_SUFFIX) + 1);
            } else if (StringUtils.endsWith(content, SIGN_SUFFIX)) {
                sign = content.substring(content.lastIndexOf(SIGN_PREFIX));
            } else {
                msg.put("sysRptCode", RptCodeConstant.SYS_STATUS_NO_REPORT_SIGN);
                return msg;
            }
            msg.put("sign", sign);
            //校验签名和拓展
            checkSignAndExtension(msg);
            sysRptCode = msg.getString("sysRptCode");
            if (StringUtils.isNotBlank(sysRptCode)) {
                return msg;
            }
            //校验通道
            checkChannel(msg);
            return msg;
        } catch (Exception e) {
            LOGGER.error("checkSign occur exception,", e);
            msg.put("rptCode", RptCodeConstant.SYS_STATUS_NO_REPORT_SIGN);
            return msg;
        }
    }

    /**
     * 校验签名和拓展码
     * <p>
     * 只要签名匹配,拓展码进行校验
     *
     * @param msg 消息
     * @return
     */
    private JSONObject checkSignAndExtension(JSONObject msg) {
        // TODO: 19-1-2 　校验签名扩展
        String userId = msg.getString("userId");
        String sign = msg.getString("sign");
        UserInfo user = CacheUtils.getBean(RedisConstant.USER_INFO_USERID + userId, UserInfo.class);
        //0为强制签名;1为自定义拓展
        int expidSign = user.getExpidSign();
        if (0 == expidSign) {
            List<Signature> signatureList = getSignaturesByUserName(userId);
            //用户签名匹配, 添加拓展
            signatureList = signatureList.stream().filter(item -> StringUtils.equals(sign, item.getSignature()))
                    .collect(Collectors.toList());
            if (CollectionUtils.isEmpty(signatureList)) {
                msg.put("sysRptCode", RptCodeConstant.USER_STATUS_NO_SIGN);
                return msg;
            }
        }
        return msg;
    }

    /**
     * 校验通道组以及通道信息
     *
     * @param msg 短信消息
     * @return
     */
    private JSONObject checkChannel(JSONObject msg) {
        //用户名
        String userId = msg.getString("userId");
        //签名
        String sign = msg.getString("sign");

        //通道产品组id
        String channelGroupId = msg.getString("channelGroupId");
        //判断通道Id 是否为空
        if (channelGroupId == null) {
            msg.put("sysRptCode", RptCodeConstant.USER_STATUS_NO_CHANNEL_GROUP);
            LOGGER.info("签名-通道组校验：用户没有对应的通道组,userName=[" + msg.getString("userNmae") + "]");
            return msg;
        }
        String channelInfoStr = CacheUtils.getString(RedisConstant.CHANNEL_GROUP_INFO + userId + channelGroupId);
        if (StringUtils.isBlank(channelInfoStr)) {
            msg.put("sysRptCode", RptCodeConstant.USER_STATUS_NO_CHANNEL);
        }
        List<Channel> channelList = JSON.parseArray(channelInfoStr, Channel.class);
        //筛选状态可用channel
        channelList = channelList.stream()
                .filter(channel -> ChannelStatus.NORMAL.getCode() == channel.getStatus())
                .collect(Collectors.toList());
        //判断可用通道
        if (CollectionUtils.isEmpty(channelList)) {
            msg.put("sysRptCode", RptCodeConstant.USER_STATUS_NO_CHANNEL);
            LOGGER.info("签名-通道校验：通道组没有对应的通道,channelGroupId=[" + channelGroupId + "]");
            return msg;
        }
        //绑定通道
        return bindChannelAndExtNo(msg, channelList, userId, sign);
    }

    /**
     * 绑定通道和拓展信息
     *
     * @param msg         消息
     * @param channelList 通道list
     * @param userId    用户
     * @param sign        签名
     * @return
     */
    public JSONObject bindChannelAndExtNo(JSONObject msg, List<Channel> channelList, String userId, String sign) {

        //单通道
        if (1 == channelList.size()) {
            Channel channel = channelList.get(0);
            //根据当前通道绑定channelId和拓展
            return packageChannel(msg, channel, userId, sign);
            //多通道
        } else {
            //筛选出有效的通道 ( 自定义通道 + 先发送后报备通道 + 先报备后发送通道(需要满足该通道签名中存在当前短信的签名)
            List<Channel> availableList = Lists.newArrayList();
            for (Channel channel : channelList) {
                Integer recordType = channel.getRecordType();
                if (ChannelRecordType.REPORT.getCode() == recordType) {
                    List<Signature> signatureList = getSignaturesByChannelId(userId, channel.getId());

                    Optional<Signature> optional = signatureList.stream()
                            .filter(item -> StringUtils.equals(sign, item.getSignature()))
                            .findFirst();

                    if (optional.get() == null) {
                        continue;
                    }
                }
                availableList.add(channel);
            }
            //根据权重进行分配通道
            Channel channel = randomChannel(msg, availableList);
            if (channel == null) {
                msg.put("rptCode", RptCodeConstant.USER_STATUS_NO_CHANNEL);
                return msg;
            }
            //根据当前通道绑定channelId和拓展
            return packageChannel(msg, channel, userId, sign);
        }
    }


    /**
     * @param msg     消息
     * @param channel 通道
     * @param userId  用户
     * @param sign    签名
     * @return
     */
    public JSONObject packageChannel(JSONObject msg, Channel channel, String userId, String sign) {
        //获取当前用户所有的签名
        List<Signature> signatureList = getSignaturesByChannelId(userId, channel.getId());

        Optional<Signature> optional = signatureList.stream()
                .filter(item -> StringUtils.equals(sign, item.getSignature()))
                .findFirst();

        Signature signature = optional.get();

        //通道报备方式：0为无,1为先报备后发,2为先发后报备
        Integer recordType = channel.getRecordType();
        //自定义,直接保存通道Id
        if (ChannelRecordType.SELF.getCode() == recordType) {
            msg.put("channelId", channel.getId());
            //先发后报备
        } else if (ChannelRecordType.SEND.getCode() == recordType) {
            //如果没有找到对应的通道签名,则创建签名
            if (signature != null) {
                msg.put("extNo", signature.getChannelExtension());
            }
            msg.put("channelId", channel.getId());
            //先报备后发送
        } else if (ChannelRecordType.REPORT.getCode() == recordType) {
            //没有对应的签名不给发的
            if (signature == null) {
                msg.put("sysRptCode", RptCodeConstant.USER_STATUS_NO_SIGN);
            } else {
                msg.put("channelId", channel.getId());
                msg.put("extNo", signature.getChannelExtension());
            }
        }
        return msg;
    }

    /**
     * 查找用户拥有的所有签名
     *
     * @param userName
     * @return
     */
    public List<Signature> getSignaturesByUserName(String userName) {
        String key = RedisConstant.USER_SIGNATURE_INFO + userName;
        String str = CacheUtils.getString(key);
        if (StringUtils.isBlank(str)) {
            return Collections.emptyList();
        }
        List<Signature> signatureList = JSON.parseArray(str, Signature.class);
        return signatureList;
    }

    /**
     * 查找该用户以及通道对应的签名
     *
     * @param userId
     * @param channelId
     * @return
     */
    public List<Signature> getSignaturesByChannelId(String userId, String channelId) {
        String key = RedisConstant.USER_SIGNATURE_INFO + userId;
        String str = CacheUtils.getString(key);
        if (StringUtils.isBlank(str)) {
            return Collections.emptyList();
        }
        List<Signature> signatureList = JSON.parseArray(str, Signature.class);
        return signatureList.stream()
                .filter(signature -> StringUtils.equals(channelId, signature.getChannelId()))
                .collect(Collectors.toList());
    }


    /**
     * 根据当前多个可用channel 根据权重随机分配 channel
     *
     * @param msg           短信消息
     * @param availableList 可用通道
     */
    private Channel randomChannel(JSONObject msg, List<Channel> availableList) {
        String channelGroupId = msg.getString("channelGroupId");

        String tenantId = msg.getString("tenantId");

        int totalWeight = 0;

        Map<String, Integer> weightMap = new HashMap<>(10);
        for (Channel channel : availableList) {
            String relatationStr = CacheUtils.getString(RedisConstant.CHANNEL_GROUP_RELATION_INFO
                    + channelGroupId + ":" + channel.getId() + ":" + tenantId);
            JSONObject jsonObject = JSON.parseObject(relatationStr);
            int weight = jsonObject.getIntValue("weight");
            weightMap.put(channel.getId(), weight);
            totalWeight += weight;
        }

        if (totalWeight <= 0) {
            LOGGER.error("Error: totalWeight  has error");
            return null;
        }
        // n in [0, totalWeight)
        Integer n = new Random().nextInt(totalWeight);
        Integer m = 0;
        Channel result = null;
        for (Channel channel : availableList) {
            if (m <= n && n < m + weightMap.get(channel.getId())) {
                result = channel;
                break;
            }
            m += weightMap.get(channel.getId());
        }
        return result;
    }
}
