package com.sms.sioo.core.service.repository.data;

import lombok.Data;
import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

import java.util.Date;

/**
 * Project:sioo-sms
 * File: com.sms.sioo.core.service.repository.data
 *
 * @author : xywei
 * @date : 2019-01-14
 * Copyright 2006-2019 Sioo Co., Ltd. All rights reserved.
 */


/**
 * 短信审核详情表
 *
 * @author xywei
 */
@Document(collection = "sms_msg_verify")
@Data
public class MsgVerifyData {

    @Id
    private String id;

    /**
     * 批次id
     */
    private Long batchId;

    /**
     * 用户userName
     */
    private String userId;

    /**
     * 租户Id
     */
    private String tenantId;

    /**
     * 用户单价
     */
    private String price;
    /**
     * 所属地区
     */
    private String location;

    /**
     * 用户提交时间
     */
    private Long userSubDate;

    /**
     * 手机号码
     */
    private String mobile;
    /**
     * 手机号运营商
     */
    private Integer mtype;

    /**
     * 信息来源  0:api接口数据  1:Web数据
     */
    private String source;

    /**
     * 短信内容
     */
    private String content;

    /**
     * 内容条数
     */
    private Integer contentNum;

    /**
     * 签名拓展码
     */
    private String extNo;

    /**
     * 通道id
     */
    private String channelId;

    /**
     * 审核状态表
     */
    private int status;

    /**
     * 创建时间
     */
    private Date createDate = new Date();

    /**
     * 更新时间
     */
    private Date updateDate = new Date();

}
