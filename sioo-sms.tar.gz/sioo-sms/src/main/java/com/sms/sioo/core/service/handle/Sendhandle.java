package com.sms.sioo.core.service.handle;

import com.alibaba.fastjson.JSONObject;
import com.sms.sioo.core.service.config.redis.CacheUtils;
import com.sms.sioo.core.service.config.redis.RedisConstant;
import com.sms.sioo.core.service.pojo.Channel;
import com.sms.sioo.core.service.pojo.ChannelConnection;
import com.sms.sioo.core.service.utils.SmsCache;
import com.sms.sioo.core.service.utils.SmsTaskQueue;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.amqp.AmqpException;
import org.springframework.amqp.core.AmqpTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Map;

/**
 * 发送数据
 *
 * @Author: creep
 * @Date: 2018/12/25 下午4:08
 */


@Service
public class Sendhandle {

    @Autowired
    private AmqpTemplate rabbitTemplate;

    private static final Logger LOGGER = LoggerFactory.getLogger(Sendhandle.class);

    public void executeHandle(JSONObject msg) {
        boolean release = msg.getBooleanValue("release");
        String sysRptCode = msg.getString("sysRptCode");

        //校验通过并且需要审核    msg -> 审核详情表 & -> 短息批次表
        //否则插入信息至短信详情表

        if (release && StringUtils.isBlank(sysRptCode)) {
            SmsTaskQueue.SAVE_VERIFY_QUEUE.add(msg);
        } else {
            SmsTaskQueue.SAVE_DTL_QUEUE.add(msg);
        }
        // 无需审核并且校验通过 -> 可以发送
        if (!release && StringUtils.isBlank(sysRptCode)) {
            send(msg);
        }
    }


    /**
     * 发送短信
     *
     * @param msg
     */
    private void send(JSONObject msg) {
        try {
            //是否需要审核
            String channelId = msg.getString("channelId");
            Channel channel = CacheUtils.getBean(RedisConstant.CHANNEL_INFO + channelId, Channel.class);
            //通道的type
            int type = channel.getType();
            rabbitTemplate.convertAndSend("sms.send", "SEND_QUEUE_" + type, msg);
            LOGGER.info("SEND_QUEUE_" + type + ",mobile:" + msg.getString("mobile") + ",content:" + msg.getString("content"));
        } catch (AmqpException e) {
            LOGGER.error(e.getMessage(), e);
        }
    }


    /**
     * 发送短信
     *
     * @param channelId
     * @param obj
     */
    private void send(int channelId, JSONObject obj) {
        try {
            Map<Integer, ChannelConnection> conn = SmsCache.CHANNEL_CONNCETION.get(channelId);
            if (conn == null || conn.size() == 0) {
                LOGGER.info("未找到消息队列：" + obj.getString("mobile"));
                return;
            } else if (conn.size() == 1) {
                for (Map.Entry<Integer, ChannelConnection> entry : conn.entrySet()) {
                    rabbitTemplate.convertAndSend("sms.send", "SEND_QUEUE_" + entry.getValue().getNo(), obj);
                    LOGGER.info("SEND_QUEUE_" + entry.getValue().getNo() + "," + obj.getString("mobile"));
                    return;
                }
            } else if (conn.size() == 3) {
                ChannelConnection connection = conn.get(SmsCache.USERINFO.get(obj.getIntValue("userName")).getUserKind());
                rabbitTemplate.convertAndSend("sms.send", "SEND_QUEUE_" + connection.getNo(), obj);
                LOGGER.info("SEND_QUEUE_" + connection.getNo() + "," + obj.getString("mobile"));
                return;
            } else {
                ChannelConnection connection = null;
                int userKind = SmsCache.USERINFO.get(obj.getIntValue("userName")).getUserKind();
                if (userKind == 1) {
                    connection = conn.get(2);
                } else if (userKind == 2) {
                    connection = conn.get(3);
                } else {
                    connection = conn.get(2);
                }
                rabbitTemplate.convertAndSend("sms.send", "SEND_QUEUE_" + connection.getNo(), obj);
                LOGGER.info("SEND_QUEUE_" + connection.getNo() + "," + obj.getString("mobile"));
                return;
            }
        } catch (AmqpException e) {
            LOGGER.error(e.getMessage(), e);
        }
    }
}
