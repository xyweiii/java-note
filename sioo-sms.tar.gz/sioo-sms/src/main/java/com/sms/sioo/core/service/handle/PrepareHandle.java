package com.sms.sioo.core.service.handle;

import com.alibaba.fastjson.JSONObject;
import com.sms.sioo.core.service.config.redis.CacheUtils;
import com.sms.sioo.core.service.handle.constant.RptCodeConstant;
import com.sms.sioo.core.service.handle.tools.DataTools;
import com.sms.sioo.core.service.pojo.UserInfo;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

/**
 * Project:sioo-sms
 * File: com.sms.sioo.core.service.handle
 *
 * @author : xywei
 * @date : 2019-01-14
 * Copyright 2006-2019 Sioo Co., Ltd. All rights reserved.
 */

/**
 * 校验之前对数据进行封装处理
 * <p>
 * 消息处理 type 类型（1为CMPP优先队列，2为CMPP普通队列，3为CMPP营销队列，4为HTTP优先队列，5为HTTP普通队列，6为HTTP营销队列）
 *
 * @author xywei
 */
@Service
public class PrepareHandle {

    private static final Logger LOGGER = LoggerFactory.getLogger(PrepareHandle.class);


    /**
     * 默认归属地
     */
    public static String defaultLocation = "全国,-1";

    @Value("${sioo.sms.mobile.yd}")
    public String ydMobile;

    @Value("${sioo.sms.mobile.lt}")
    public String ltMobile;

    @Value("${sioo.sms.mobile.dx}")
    public String dxMobile;


    /**
     * @param msg  短信消息
     * @param type 类型
     * @return
     */
    public JSONObject executeHandle(JSONObject msg, int type, UserInfo user) {
        String userId = msg.getString("userId");
        //记录用户单价
        msg.put("price", user.getPrice());
        //拼接内容 回T
        DataTools.appendTxt(msg, user);

        // 计算手机号码数
        calcMobileNum(msg, type);

        //拼接签名
        //判断数据源  0表示接口数据  1表示Web数据
        if (msg.getIntValue("source") == 0) {
            // 是否包含签名、获取用户签名列表
            if (!DataTools.appendSign(msg, user)) {
                msg.put("sysRptCode", RptCodeConstant.USER_STATUS_NO_SIGN);
                LOGGER.info(String.format("签名校验失败: mobile: [%s] ,userId: [%s] ", msg.getString("mobile")), userId);
            }
        }
        // 计算短信条数
        msg.put("contentNum", DataTools.calcContentNum(msg.getString("content")));
        //生成 batchId 和uniqueId
        dealBatchIdAndUniqueId(type, msg);
        return msg;
    }

    /**
     * 统计批次发送手机号数量
     *
     * @param type
     * @param msg
     */
    private void calcMobileNum(JSONObject msg, int type) {
        int mobileNum;
        if (type == 3) {
            mobileNum = msg.getString("mobile").split(";").length;
        } else {
            mobileNum = msg.getString("mobile").split(",").length;
        }
        msg.put("mobileNum", mobileNum);
    }

    /**
     * 生成 batchId 和 uniqueId
     * <p>
     * 因为CMPP接口已经生成过uniqueId，HTTP接口已经生成过batchId
     *
     * @param type
     * @param msg
     */
    private void dealBatchIdAndUniqueId(int type, JSONObject msg) {

        switch (type) {
            case 1:
                msg.put("batchId", CacheUtils.getSeqNext("sms_batch_id"));
                break;
            case 2:
                msg.put("batchId", CacheUtils.getSeqNext("sms_batch_id"));
                break;
            case 4:
                msg.put("uniqueId", CacheUtils.getSeqNext("sms_unique_id"));
                break;
            case 5:
                msg.put("uniqueId", CacheUtils.getSeqNext("sms_unique_id"));
                break;
            case 6:
                msg.put("uniqueId", CacheUtils.getSeqNext("sms_unique_id"));
                break;

            default:
                break;
        }
    }
}
