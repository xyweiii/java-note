package com.sms.sioo.core.service.handle;

import com.alibaba.fastjson.JSONObject;
import com.sms.sioo.core.service.config.redis.CacheUtils;
import com.sms.sioo.core.service.config.redis.RedisConstant;
import com.sms.sioo.core.service.handle.constant.MsgConstant;
import com.sms.sioo.core.service.handle.constant.RptCodeConstant;
import com.sms.sioo.core.service.pojo.UserInfo;
import com.sms.sioo.core.service.utils.SmsCache;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.lang.reflect.Array;
import java.util.ArrayList;

/**
 * 黑名、白名单校验
 *
 * @Author: creep
 * @Date: 2018/12/21 下午4:27
 */

@Service
public class BlackAndWhiteMobileHandle {

    private static final Logger LOGGER = LoggerFactory.getLogger(BlackAndWhiteMobileHandle.class);

    public JSONObject executeHandle(JSONObject msg) {
        try {
            String sysRptCode = msg.getString(MsgConstant.SYSRPTCODE);
            if (StringUtils.isNotBlank(sysRptCode)) {
                return msg;
            }
            String userId = msg.getString("userId");
            // TODO: 19-1-3 判断用户黑名单
            String mobile = msg.getString("mobile");
            // 手机号码白名单校验
            if (CacheUtils.isCached(RedisConstant.USER_WHITE_MOBILE + mobile)) {
                LOGGER.info("用户白名单校验,userId=[" + userId + "]处于白名单");
                return msg;
            }
            // 手机号码黑名单校验
            if (CacheUtils.isCached(RedisConstant.USER_BLACK_MOBILE + mobile)) {
                msg.put("sysRptCode", RptCodeConstant.USER_STATUS_BLACK_MOBILE);
                LOGGER.info("用户黑名单校验,userId=[" + userId + "]处于黑名单");
                return msg;
            }
        } catch (Exception e) {
            msg.put("sysRptCode", RptCodeConstant.SYS_STATUS_BLACK_MOBILE);
            LOGGER.error("黑白名单校验发生异常,mobile=[" + msg.getString("mobile") + "],error:" + e.getMessage());
        }
        return msg;
    }
}
