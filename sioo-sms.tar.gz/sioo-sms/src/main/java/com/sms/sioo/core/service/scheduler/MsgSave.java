package com.sms.sioo.core.service.scheduler;

import com.alibaba.fastjson.JSONObject;
import com.sms.sioo.core.service.utils.SmsCache;
import com.sms.sioo.core.service.utils.SmsTaskQueue;
import org.bson.Document;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.data.mongodb.core.MongoTemplate;

import java.util.ArrayList;
import java.util.List;

/**
 * 内容入库
 */
public class MsgSave implements Runnable {

    private static final Logger LOG = LoggerFactory.getLogger(MsgSave.class);

    private MongoTemplate mongoTemplate;

    public MsgSave(MongoTemplate mongoTemplate){
        this.mongoTemplate = mongoTemplate;
    }


    /**
     * When an object implementing interface <code>Runnable</code> is used
     * to create a thread, starting the thread causes the object's
     * <code>run</code> method to be called in that separately executing
     * thread.
     * <p>
     * The general contract of the method <code>run</code> is that it may
     * take any action whatsoever.
     *
     * @see Thread#run()
     */
    @Override
    public void run() {
        while (true){
            try {
                List<JSONObject> list = new ArrayList<>();
                long l = System.currentTimeMillis();
                int count = SmsTaskQueue.SAVE_DTL_QUEUE.drainTo(list, 5000);
                if(count > 0){
                    try{
                        List<Document> insertList = new ArrayList<>();
                        for(JSONObject obj : list){
                            Document cument = new Document();
                            cument.put("cid",obj.getIntValue("cid"));
                            cument.put("userName",obj.getIntValue("userName"));
                            cument.put("uniqueId",obj.getLongValue("uniqueId"));
                            cument.put("senddate",obj.getLongValue("senddate"));
                            cument.put("mtype",obj.getIntValue("mtype"));
                            cument.put("mobile",obj.getLongValue("mobile"));
                            cument.put("batchId",obj.getLongValue("batchId"));
                            cument.put("contentNum",obj.getIntValue("contentNum"));
                            cument.put("channelId",obj.getIntValue("channelId"));
                            cument.put("subSucc",obj.getIntValue("subSucc"));
                            cument.put("subFail",obj.getIntValue("subFail"));
                            cument.put("rptSucc",obj.getIntValue("rptSucc"));
                            cument.put("rptFail",obj.getIntValue("rptFail"));
                            cument.put("extNo",obj.getString("extno"));
                            cument.put("location",obj.getString("location"));
                            insertList.add(cument);
                        }
                        mongoTemplate.getCollection("sms_msg_dtl").insertMany(insertList);
                    }catch(Exception e){
                        LOG.error(e.getMessage(),e);
                    }finally {
                        list.clear();
                    }
                    LOG.info("batch insert msg dtl size["+count+"]-time-consuming:"+(System.currentTimeMillis()-l));
                }
            } catch (Exception e) {
                LOG.error(e.getMessage(),e);
            }
            try {
                Thread.sleep(100);
            } catch (InterruptedException e) {
            }
        }
    }
}
