package com.sms.sioo.core.service.handle;

import com.alibaba.fastjson.JSONObject;
import com.sms.sioo.core.service.config.redis.CacheUtils;
import com.sms.sioo.core.service.config.redis.RedisConstant;
import com.sms.sioo.core.service.handle.constant.RptCodeConstant;
import com.sms.sioo.core.service.pojo.AreaBlack;
import com.sms.sioo.core.service.utils.SmsCache;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.Map;

/**
 * 校验屏蔽地区 [用户屏蔽地区、通道屏蔽地区]
 *
 * @Author: creep
 * @Date: 2018/12/25 下午3:58
 */

@Service
public class BlackAreaHandle {
    private static final Logger LOGGER = LoggerFactory.getLogger(BlackAreaHandle.class);


    public JSONObject executeHandle(JSONObject msg) {
        //用户屏蔽地区
        checkForUser(msg);
        //通道屏蔽地区
        String sysRptCode = msg.getString("sysRptCode");
        if (StringUtils.isNotBlank(sysRptCode)) {
            checkForChannel(msg);
        }
        return msg;
    }

    /**
     * 校验用户屏蔽地区
     *
     * @param msg
     * @return
     */
    public JSONObject checkForUser(JSONObject msg) {
        String localtion = msg.getString("location");

        if (StringUtils.isNotBlank(localtion) ||
                !StringUtils.equals(UserPropertyHandle.defaultLocation, localtion)) {
            return msg;
        }
        String userId = msg.getString("userId");
        String provinceCode = msg.getString("provinceCode");
        String cityCode = msg.getString("cityCode");

        boolean result = CacheUtils.isCached(RedisConstant.USER_BLACK_AREA
                + provinceCode + ":" + cityCode + ":" + userId);
        if (result) {
            msg.put("sysRptCode", RptCodeConstant.USER_BLACK_AREA);
            LOGGER.info("触发用户屏蔽地区; userId: " + msg.getString("userId") + ", mobile:" + msg.getLong("mobile"));
        }
        return msg;
    }


    /**
     * 检查通道地区
     *
     * @param msg
     * @return
     */
    public JSONObject checkForChannel(JSONObject msg) {
        String channelId = msg.getString("channelId");
        if (StringUtils.isNotBlank(channelId)) {
            return msg;
        }
        String provinceCode = msg.getString("provinceCode");
        String cityCode = msg.getString("cityCode");

        boolean result = CacheUtils.isCached(RedisConstant.CHANNEL_BLACK_AREA
                + provinceCode + ":" + cityCode + ":" + channelId);


        // TODO: 19-1-14 查找当前用户的路由通道


        if (result) {
            msg.put("sysRptCode", RptCodeConstant.CHANNEL_BLACK_AREA);
            LOGGER.info("触发通道屏蔽地区; userId: " + msg.getString("userId") + ", mobile:" + msg.getLong("mobile"));
        }
        return msg;
    }

}