package com.sms.sioo.core.service.handle;

import com.alibaba.fastjson.JSONObject;
import com.sms.sioo.core.service.config.redis.CacheUtils;
import com.sms.sioo.core.service.config.redis.RedisConstant;
import com.sms.sioo.core.service.pojo.UserInfo;
import org.springframework.stereotype.Service;

/**
 * 计费
 *
 * @Author: creep
 * @Date: 2018/12/24 下午4:43
 */

@Service
public class ChargingHandle {


    public JSONObject executeHandle(JSONObject msg ,UserInfo user) {


        Double total  =  user.getPrice() * msg.getIntValue("contentNum");

        System.out.println(total);


        /*
         * 计费 ：
         *
         *      if(余额足够){
         *       根据当前批次数据量>1 生成订单交易表(trade_order) 和流水表(balance_log) 否则 直接走下面流程
                 mysql 用户余额 update

         *      }
         *       MongoDB： 批次信息 sms_msg_batch ，详情 sms_msg_dtl
                 mysql ：状态表 sms_rpt_dtl 所有状态更新
         *
         */

        return null;
    }
}
