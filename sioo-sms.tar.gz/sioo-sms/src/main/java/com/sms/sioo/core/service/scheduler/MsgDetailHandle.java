package com.sms.sioo.core.service.scheduler;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.google.common.collect.Lists;
import com.sms.sioo.core.service.repository.data.MsgVerifyData;
import com.sms.sioo.core.service.utils.SmsTaskQueue;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Component;

import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

/**
 * 存储短信批次信息
 *
 * @author xywei
 */
@Component
public class MsgDetailHandle implements Runnable, InitializingBean {

    public static final Logger LOGGER = LoggerFactory.getLogger(MsgDetailHandle.class);

    @Autowired
    private MongoTemplate mongoTemplate;

    private static final List<JSONObject> msgDetailList = Lists.newArrayList();

    @Override
    public void run() {
        try {
            while (true) {
                int count = SmsTaskQueue.SAVE_DTL_QUEUE.drainTo(msgDetailList, 1000);
                if (count > 0) {
                    List<MsgVerifyData> dataList = msgDetailList.parallelStream().map(item -> {
                        MsgVerifyData msgVerifyData = JSON.parseObject(item.toJSONString(), MsgVerifyData.class);
                        return msgVerifyData;
                    }).collect(Collectors.toList());
                    mongoTemplate.insertAll(dataList);
                } else {
                    TimeUnit.MILLISECONDS.sleep(1000);
                }
            }
        } catch (Exception e) {
            LOGGER.info("MsgDetailHandle occur error , ");
        }
    }

    @Override
    public void afterPropertiesSet() {
        new Thread(this).start();
    }
}
