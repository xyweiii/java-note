package com.sms.sioo.core.service.handle;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.sms.sioo.core.service.config.redis.CacheUtils;
import com.sms.sioo.core.service.config.redis.RedisConstant;
import com.sms.sioo.core.service.pojo.UserTemplate;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.regex.Pattern;

/**
 * @Author: creep
 * @Date: 2018/12/21 下午4:59
 */

@Service
public class TemplateHandle {

    private static final Logger LOGGER = LoggerFactory.getLogger(TemplateHandle.class);

    /**
     * 模板校验
     *
     * @param msg
     * @return
     */
    public JSONObject executeHandle(JSONObject msg) {
        try {
            String useId = msg.getString("userId");
            String templateStr = CacheUtils.getString(RedisConstant.USER_TEMPLATE + useId);
            if (StringUtils.isBlank(templateStr)) {
                msg.put("template", false);
                return msg;
            }
            List<UserTemplate> templates = JSON.parseArray(templateStr, UserTemplate.class);
            for (UserTemplate template : templates) {
                Pattern pattern = Pattern.compile(template.getContent());
                if (template.getType() == 0 || (template.getType() == 1 && template.getEndDate().getTime() > System.currentTimeMillis())) {
                    if (pattern.matcher(msg.getString("content")).matches()) {
                        msg.put("template", true);
                        return msg;
                    }
                }
            }
            msg.put("template", false);
            return msg;
        } catch (Exception e) {
            LOGGER.info("TemplateHandle has occur error,msg:" + msg.toJSONString());
            msg.put("template", false);
            return msg;
        }
    }
}
