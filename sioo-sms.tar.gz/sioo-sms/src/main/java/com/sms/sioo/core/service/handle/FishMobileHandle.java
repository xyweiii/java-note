package com.sms.sioo.core.service.handle;

import com.alibaba.fastjson.JSONObject;
import com.sms.sioo.core.service.config.redis.CacheUtils;
import com.sms.sioo.core.service.config.redis.RedisConstant;
import com.sms.sioo.core.service.handle.constant.RptCodeConstant;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

/**
 * 钓鱼号码校验
 *
 * @Author: creep
 * @Date: 2018/12/20 下午2:05
 */

@Service
public class FishMobileHandle {

    private static final Logger LOGGER = LoggerFactory.getLogger(FishMobileHandle.class);

    /**
     * XA:0139 触发系统黑名单
     *
     * @param msg
     * @return JSONObject
     */
    public JSONObject executeHandle(JSONObject msg) {
        try {
            String sysRptCode = msg.getString("sysRptCode");
            if (StringUtils.isNotBlank(sysRptCode)) {
                return msg;
            }
            //判断钓鱼号码,系统黑名单
            String mobile = msg.getString("mobile");
            // TODO: 19-1-9 校验钓鱼号码
            if (CacheUtils.isCached(RedisConstant.FISH_MOBILE + mobile)) {
                msg.put("sysRptCode", RptCodeConstant.SYS_STATUS_BLACK_MOBILE);
                LOGGER.info("发现DY号码:[" + msg.getLong("mobile") + "],"
                        + "用户id:[" + msg.getString("userId" + "],")
                        + "内容:[" + msg.getString("content") + "]");
            }
        } catch (Exception e) {
            LOGGER.error("钓鱼号码校验发生异常,mobile=[" + msg.getString("mobile") + "],error:" + e.getMessage());
        }
        return msg;
    }
}
