package com.sms.sioo.core.service.handle.tools;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.sms.sioo.core.service.config.redis.CacheUtils;
import com.sms.sioo.core.service.config.redis.RedisConstant;
import com.sms.sioo.core.service.pojo.Signature;
import com.sms.sioo.core.service.pojo.UserInfo;
import org.apache.commons.collections.CollectionUtils;
import org.apache.commons.lang3.StringUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;

/**
 * @Author: creep
 * @Date: 2018/12/25 下午3:34
 */
public class DataTools {

    private static final Logger LOGGER = LoggerFactory.getLogger(DataTools.class);


    /**
     * 对数据进行拆分为多条数据
     *
     * @param obj 消息
     * @return
     */
    public static List<JSONObject> convert(JSONObject obj) {
        List<JSONObject> list = new ArrayList<>();
        int type = obj.getIntValue("type");
        //CMPP营销处理方式不一样
        if (2 == type || 3 == type) {
            String[] mu = obj.getString("mobile").split(";");
            for (String str : mu) {
                String[] s = str.split("-");
                JSONObject send = new JSONObject();
                send.put("sendDate", obj.getLong("sendDate"));
                send.put("tenantId", obj.getString("tenantId"));
                send.put("useId", obj.getString("useId"));
                send.put("mobile", Long.parseLong(s[0]));
                send.put("uniqueId", Long.parseLong(s[1]));
                send.put("content", obj.getString("content"));
                send.put("extNo", obj.getString("extNo"));
                send.put("source", obj.getInteger("source"));
                send.put("batchId", obj.getLong("batchId"));
                send.put("contentNum", obj.getInteger("contentNum"));
                //是否审核
                send.put("release", obj.getBooleanValue("release"));
                send.put("price", obj.getDoubleValue("price"));
                send.put("sysRptCode", obj.getString("sysRptCode"));
                list.add(send);
            }
        } else {
            String[] mobiles = obj.getString("mobile").split(",");
            for (String mobile : mobiles) {
                JSONObject send = new JSONObject();
                send.put("sendDate", obj.getLong("sendDate"));
                send.put("tenantId", obj.getIntValue("tenantId"));
                send.put("userId", obj.getString("userId"));
                send.put("mobile", mobile);
                send.put("content", obj.getString("content"));
                send.put("extNo", obj.getString("extNo"));
                send.put("source", obj.getInteger("source"));
                send.put("contentNum", obj.getInteger("contentNum"));
                send.put("batchId", obj.getString("batchId"));
                send.put("uniqueId", obj.getString("uniqueId"));

                send.put("release", obj.getBooleanValue("release"));
                send.put("price", obj.getDoubleValue("price"));
                send.put("sysRptCode", obj.getString("sysRptCode"));


                /*//因为CMPP接口已经生成过uniqueId，HTTP接口已经生成过batchId
                if (obj.containsKey("uniqueId")) {
                    send.put("uniqueId", obj.getLong("uniqueId"));
                }
                if (obj.containsKey("batchId")) {
                    send.put("batchId", obj.getLong("batchId"));
                }
                switch (type) {
                    case 1:
                        send.put("batchId", CacheUtils.getSeqNext("sms_batch_id"));
                        break;
                    case 2:
                        send.put("batchId", CacheUtils.getSeqNext("sms_batch_id"));
                        break;
                    case 4:
                        send.put("uniqueId", CacheUtils.getSeqNext("sms_unique_id"));
                        break;
                    case 5:
                        send.put("uniqueId", CacheUtils.getSeqNext("sms_unique_id"));
                        break;
                    case 6:
                        send.put("uniqueId", CacheUtils.getSeqNext("sms_unique_id"));
                        break;
                }*/
                list.add(send);
            }
        }
        return list;
    }

    /**
     * 短信内容拼接签名
     *
     * @param msg
     * @return
     */
    public static boolean appendSign(JSONObject msg, UserInfo user) {
        try {
            String content = msg.getString("content");
            //如果内容不包含签名
            boolean exclusive = (!content.startsWith("【") && !content.endsWith("】")) ||
                    (content.endsWith("】") && !content.contains("【")) ||
                    (content.startsWith("【") && !content.contains("】"));
            if (exclusive) {
                //此处需要替换成redis获取用户签名列表
                String signStr = CacheUtils.getString(RedisConstant.USER_SIGNATURE_INFO + msg.getString("userId"));
                if (StringUtils.isBlank(signStr)) {
                    return false;
                }
                List<Signature> signatures = JSON.parseArray(signStr, Signature.class);
                if (CollectionUtils.isEmpty(signatures)) {
                    LOGGER.info("签名校验,没有可用签名,msg :" + msg.toString());
                    return false;
                }

                for (Signature signature : signatures) {
                    if (user.getSignPosition() == 2) {
                        msg.put("content", content + signature.getSignature());
                    } else {
                        msg.put("content", signature.getSignature() + content);
                    }
                    return true;
                }
            }
        } catch (Exception e) {
            LOGGER.error("校验是否包含签名出错,msg:" + msg.toString() + ";e:" + e.getMessage());
        }
        return true;
    }


    /**
     * 根据用户配置 内容是否追加'回T退订',1为追加;0为不追加
     *
     * @param obj
     * @param user
     */
    public static void appendTxt(JSONObject obj, UserInfo user) {
        if (StringUtils.isNotEmpty(user.getAppendTxt()) && !obj.getString("content").contains(user.getAppendTxt())) {
            if (obj.getString("content").endsWith("】")) {
                String content = obj.getString("content").substring(0, obj.getString("content").lastIndexOf("【"));
                String sign = obj.getString("content").substring(obj.getString("content").lastIndexOf("【"));
                obj.put("content", content + user.getAppendTxt() + sign);
            } else {
                obj.put("content", obj.getString("content") + user.getAppendTxt());
            }
        }
    }

    /**
     * 重新根据字数计算短信条数
     *
     * @param content 内容
     * @return int
     */
    public static int calcContentNum(String content) {
        // 重新计算条数
        int contentLength = content.length();
        int cCount = contentLength > 70 ? 67 : 70;
        if (contentLength % cCount != 0) {
            cCount = (contentLength / cCount) + 1;
        } else {
            cCount = contentLength / cCount;
        }
        return cCount;
    }


    /**
     * 匹配词语
     *
     * @param content 短信内容
     * @param word    单词
     * @return
     */
    public static String matchWord(String content, String word) {
        try {
            String[] regs = word.split("&");
            boolean regResult = true;
            for (String reg : regs) {
                if (StringUtils.startsWith(reg, "(") && StringUtils.endsWith(reg, ")")) {
                    reg = reg.substring(1, reg.length() - 1);
                }
                String[] splits = reg.split("\\|");
                int result = 0;
                for (String split : splits) {
                    if (StringUtils.contains(content, split)) {
                        result = 1;
                        break;
                    }
                }
                if (result != 1) {
                    regResult = false;
                    break;
                }
            }
            if (regResult) {
                return word;
            }
        } catch (Exception e) {
            LOGGER.error(e.getMessage(), e);
        }
        return null;
    }
}
