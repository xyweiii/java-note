package com.sms.sioo.core.service.pojo;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class UserRoute {

    /**
     * 路由内容
     */
    private String content;

    /**
     * 路由通道
     */
    private Integer routeChannel;

    /**
     * 路由用户
     */
    private Integer username;

    /**
     * 类型
     */
    private Integer mType;

    /**
     * 关键词类型
     */
    private Integer contentType;

    /**
     * 省
     */
    private Integer province;

    /**
     * 市
     */
    private Integer city;
}
