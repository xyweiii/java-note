package com.sms.sioo.core.service.config.enums;

/**
 * Project:sioo-sms
 * File: com.sms.sioo.core.service.config.enums
 *
 * @author : xywei
 * @date : 2019-01-07
 * Copyright 2006-2019 Sioo Co., Ltd. All rights reserved.
 */
public enum ChannelRecordType {
    /**
     * 自定义
     */
    SELF(0, "自定义"),
    /**
     * 先发后报备
     */
    SEND(1, "先发送后报备"),
    /**
     * 先报备后发
     */
    REPORT(2, "先报备后发送");


    private int code;
    private String description;

    ChannelRecordType(int code, String description) {
        this.code = code;
        this.description = description;
    }

    public int getCode() {
        return code;
    }

    public String getDescription() {
        return description;
    }
}
