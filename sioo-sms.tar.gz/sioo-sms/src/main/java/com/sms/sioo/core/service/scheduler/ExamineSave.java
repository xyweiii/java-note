/*
package com.sms.sioo.core.service.scheduler;

import com.alibaba.fastjson.JSONObject;
import com.sms.sioo.core.service.async.ExamineAsync;
import com.sms.sioo.core.service.config.redis.CacheUtils;
import com.sms.sioo.core.service.dao.ManagerBaseDao;
import com.sms.sioo.core.service.utils.Md5Util;
import com.sms.sioo.core.service.utils.SmsCache;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.jdbc.datasource.DataSourceUtils;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CompletableFuture;
import java.util.concurrent.Executors;
import java.util.concurrent.ThreadPoolExecutor;

*/
/**
 * 统计入库
 *//*

public class ExamineSave implements Runnable {

    private static final Logger LOG = LoggerFactory.getLogger(ExamineSave.class);

    private ManagerBaseDao managerDao;

    private ExamineAsync examineAsync;

    public ExamineSave(ManagerBaseDao managerDao, ExamineAsync examineAsync){
        this.managerDao = managerDao;
        this.examineAsync = examineAsync;
    }


    private ThreadPoolExecutor threadPool = (ThreadPoolExecutor) Executors.newFixedThreadPool(10);

    private void saveOrUpdate(Map<String, JSONObject> mdstrMap){
        try {
            Connection conn = DataSourceUtils.getConnection(managerDao.getSqlSession().getConfiguration().getEnvironment().getDataSource());
            conn.setAutoCommit(false);
            PreparedStatement update = conn.prepareStatement("UPDATE sioo_paas.sms_release_count SET mobiles=mobiles+? WHERE mdstr=?");
            PreparedStatement insert = conn.prepareStatement("INSERT INTO sioo_paas.sms_release_count(mtype,senddate,username,channel,content,content_num,mdstr,screen_type,remark,`level`,mobiles,cid) VALUES(?,?,?,?,?,?,?,?,?,?,?,?);");
            boolean isUpdate = false, isInsert = false;
            for(Map.Entry<String, JSONObject> entry : mdstrMap.entrySet()){
                if(CacheUtils.isCached("examine_"+entry.getKey())){
                    isUpdate = true;
                    update.setInt(1,entry.getValue().getIntValue("mobiles"));
                    update.setString(2,entry.getValue().getString("mdstr"));
                    update.addBatch();
                }else{
                    isInsert = true;
                    CacheUtils.saveString("examine_"+entry.getKey(), "",24*3600);
                    JSONObject obj = entry.getValue();

                    insert.setInt(1,obj.getIntValue("mtype"));
                    insert.setLong(2,obj.getLongValue("sendDate"));
                    insert.setInt(3,obj.getIntValue("userName"));
                    insert.setInt(4,obj.getIntValue("channelId"));
                    insert.setString(5,obj.getString("content"));
                    insert.setInt(6,obj.getIntValue("contentNum"));
                    insert.setString(7,obj.getString("mdstr"));
                    insert.setInt(8,obj.getIntValue("screenType"));
                    insert.setString(9,obj.getString("remark"));
                    insert.setInt(10,obj.getIntValue("level"));
                    insert.setInt(11,obj.getIntValue("mobiles"));
                    insert.setInt(12,obj.getIntValue("cid"));
                    insert.addBatch();
                }
            }
            if(isUpdate){
                update.executeBatch();
            }
            if(isInsert){
                insert.executeBatch();
            }
            conn.commit();
            update.close();insert.close();
            DataSourceUtils.releaseConnection(conn,managerDao.getSqlSession().getConfiguration().getEnvironment().getDataSource());
        } catch (SQLException e) {
            LOG.error(e.getMessage(),e);
        }
    }

    */
/**
     * When an object implementing interface <code>Runnable</code> is used
     * to create a thread, starting the thread causes the object's
     * <code>run</code> method to be called in that separately executing
     * thread.
     * <p>
     * The general contract of the method <code>run</code> is that it may
     * take any action whatsoever.
     *
     * @see Thread#run()
     *//*

    @Override
    public void run() {
        while (true){
            try {
                int count = 0;
                do{
                    List<JSONObject> list = new ArrayList<>();
                    count = SmsCache.RELEASE_SENDING.drainTo(list, 1000);
                    if(count > 0){
                        Map<String, JSONObject> mdstrMap = new HashMap<String, JSONObject>();
                        for(JSONObject obj : list){
                            obj.put("mdstr", Md5Util.getMD5(obj.getIntValue("username")+"_"+obj.getIntValue("mtype")+"_"+obj.getIntValue("channel")+"_"+obj.getString("content")));
                            if(mdstrMap.containsKey(obj.getString("mdstr"))){
                                JSONObject m = mdstrMap.get(obj.getString("mdstr"));
//                                m.put("mobiles",m.getIntValue("mobiles")+obj.getIntValue("contentNum"));
                                m.put("mobiles",m.getIntValue("mobiles")+1);
                            }else{
                                JSONObject m = new JSONObject();
                                m.put("mtype",obj.getIntValue("mtype"));
                                m.put("sendDate",obj.getLongValue("senddate"));
                                m.put("userName",obj.getIntValue("userName"));
                                m.put("channelId",obj.getIntValue("channelId"));
                                m.put("content",obj.getString("content"));
                                m.put("contentNum",obj.getIntValue("contentNum"));
                                m.put("batchId",obj.getLongValue("batchId"));
                                m.put("mdstr",obj.getString("mdstr"));
                                m.put("handStat",obj.getIntValue("handStat"));
                                m.put("screenType",obj.getIntValue("screenType"));
                                m.put("remark",obj.getString("remark"));
                                m.put("level",obj.getIntValue("level"));
//                                m.put("mobiles",obj.getIntValue("contentNum"));
                                m.put("mobiles",1);
                                m.put("cid",obj.getIntValue("cid"));
                                mdstrMap.put(obj.getString("mdstr"),m);
                            }
                        }
                        saveOrUpdate(mdstrMap);
                        while(threadPool.getActiveCount() >= threadPool.getCorePoolSize()){
                            try {
                                Thread.sleep(10);
                            } catch (InterruptedException e) {
                            }
                        }
                        CompletableFuture.runAsync(() -> examineAsync.handle(list),threadPool);
                    }
                }while (count==1000);
            } catch (Exception e) {
                LOG.error(e.getMessage(),e);
            }
            try {
                Thread.sleep(300);
            } catch (InterruptedException e) {
            }
        }
    }
}
*/
