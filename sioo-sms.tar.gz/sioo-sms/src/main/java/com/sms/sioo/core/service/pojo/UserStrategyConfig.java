package com.sms.sioo.core.service.pojo;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
/**
 * 用户策略组配置
 */
public class UserStrategyConfig {

    /**
     * 用户名
     */
    private Integer username;

    /**
     *策略组ID
     */
    private Integer groupId;

    /**
     *策略组类型（1.系统屏蔽词 2审核屏蔽词 3系统黑名单  4屏蔽地区 5系统白名单 6系统白签名）
     */
    private Integer groupType;
}
