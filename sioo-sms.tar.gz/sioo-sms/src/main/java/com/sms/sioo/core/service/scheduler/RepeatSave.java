package com.sms.sioo.core.service.scheduler;

import com.sms.sioo.core.service.config.redis.CacheUtils;
import com.sms.sioo.core.service.utils.SmsCache;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import java.util.ArrayList;
import java.util.List;

/**
 * 重号过滤保存
 */
public class RepeatSave implements Runnable {

    private static final Logger LOG = LoggerFactory.getLogger(RepeatSave.class);

    List<String> list = new ArrayList<>();

    @Override
    public void run() {
        while (true){
            try {
                int count = SmsCache.REPEAT_CACHE.drainTo(list, 10000);
                if(count > 0){
                    for(String s : list){
                        String[] str = s.split("@");
                        CacheUtils.saveString("rt_"+str[0],str[1]);
                    }
                }
            } catch (Exception e) {
                LOG.error(e.getMessage(),e);
            }
        }

    }
}
