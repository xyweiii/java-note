package com.sms.sioo.core.service.pojo;

import lombok.Getter;
import lombok.Setter;

@Setter
@Getter
/**
 * 系统屏蔽词
 */
public class SysBlackWords {

    /**
     * 组名
     */
    private Integer groupId;

    /**
     * 屏蔽词
     */
    private String words;

    /**
     * 1.系统屏蔽词 2审核屏蔽词
     */
    private Integer type;

    /**
     * 屏蔽词类型
     */
    private Integer screenType;

    /**
     * 危险等级
     */
    private Integer level;

    private Integer cid;
}
