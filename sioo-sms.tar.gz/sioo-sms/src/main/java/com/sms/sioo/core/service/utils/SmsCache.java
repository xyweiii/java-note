package com.sms.sioo.core.service.utils;

import com.alibaba.fastjson.JSONObject;
import com.sms.sioo.core.service.pojo.*;

import java.util.List;
import java.util.Map;
import java.util.concurrent.BlockingQueue;
import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.LinkedBlockingQueue;

public class SmsCache {

    public static volatile boolean isruning = false;

    /**
     * 保存hbase批次记录
     */
    public static LinkedBlockingQueue<JSONObject> HISTORY = new LinkedBlockingQueue<>();

    /**
     * 通道，key:channelId
     */
    public static Map<Integer, Channel> CHANNEL = new ConcurrentHashMap<>();

    /**
     * 用户，key:userName
     */
    public static Map<Integer, UserInfo> USERINFO = new ConcurrentHashMap<>();

    /**
     * 通道屏蔽地区，key1为通道号，key2为“省编号_市编号”
     */
    public static Map<Integer,Map<String, AreaBlack>> CHANNEL_BLIACK_AREA = new ConcurrentHashMap<>();

    /**
     * 用户屏蔽地区，key1为用户名，key2为“省编号_市编号”
     */
    public static Map<Integer,Map<String, AreaBlack>> USER_BLIACK_AREA = new ConcurrentHashMap<>();

    //通道链接key1为通道号，key2为类型
    public static Map<Integer,Map<Integer, ChannelConnection>> CHANNEL_CONNCETION = new ConcurrentHashMap<>();

    //号码归属地
    public static Map<Integer, MobileArea> MOBILE_AREA = new ConcurrentHashMap<>();

    //产品信息
    public static Map<Integer, List<ProductDetail>> PRODUCT = new ConcurrentHashMap<>();

    //系统屏蔽词key:cid|value:(map key:groupId,value:词list)
    public static Map<Integer, Map<Integer, List<String>>> STS_BLACK_WORDS = new ConcurrentHashMap<>();

    //系统审核词key:cid|value:(map key:groupId,value:词list)
    public static Map<Integer, Map<Integer, List<SysBlackWords>>> STS_EXAMINE_WORDS = new ConcurrentHashMap<>();

    //用户白名单
    public static Map<Integer, Map<Long, Integer>> USER_WHITE_MOBILE = new ConcurrentHashMap<>();

    //系统白名单key:cid|value:(map key:groupId,value:map<Long, Integer> key为号码)
    public static Map<Integer, Map<Integer, Map<Long, Integer>>> STS_WHITE_MOBILE = new ConcurrentHashMap<>();

    //用户屏蔽词
    public static Map<Integer, List<String>> USER_BLACK_WORDS = new ConcurrentHashMap<>();

    //用户审核词
    public static Map<Integer, List<String>> USER_EXAMINE_WORDS = new ConcurrentHashMap<>();

    // 用户路由,key:uid
    public static Map<Integer, List<UserRoute>> USER_ROUTE = new ConcurrentHashMap<>();

    //用户策略组配置，key1为用户,key2为策略类型。value为策略组集合
    public static Map<Integer, Map<Integer, List<Integer>>> USER_STRATEGY_CONF = new ConcurrentHashMap<>();

    // 用户模板，key:uid
    public static Map<Integer, List<UserTemplate>> USER_TEMPLATE = new ConcurrentHashMap<>();

    //用户余额提醒
    public static Map<Integer, UserBalanceAlert> USER_BALANCE_ALERT = new ConcurrentHashMap<>();
    public static Map<String, Integer> IS_BALANCE_ALERT = new ConcurrentHashMap<>();

    //钓鱼号码
    public static Map<Long,Integer> FISH_MOBILE = new ConcurrentHashMap<>();

    //审核短信入库队列
    public static BlockingQueue<JSONObject> RELEASE_SENDING = new LinkedBlockingQueue<>();

    //用户签名
    public static Map<Integer, List<UserExtNo>> USER_SIGN = new ConcurrentHashMap<>();
    //通道签名
    public static Map<Integer, List<ChannelExtNo>> CHANNEL_SIGN = new ConcurrentHashMap<>();

    //平台生成的失败回执
    public static BlockingQueue<JSONObject> RPT_RESULT = new LinkedBlockingQueue<>();
//    public static BlockingQueue<JSONObject> FAIL_RPT = new LinkedBlockingQueue<JSONObject>();

    //历史记录队列
    public static BlockingQueue<JSONObject> HISTORY_QUEUE = new LinkedBlockingQueue<>();

    //用户重号过滤
    public static Map<Integer, List<UserRepeatMobile>> USER_REPEAT = new ConcurrentHashMap<>();

    //内容审核计数
    public static Map<String,Integer> EXAMINE_COUNT = new ConcurrentHashMap<>();

//    public static BlockingQueue<JSONObject> UPDATE_BATCH_FAIL = new LinkedBlockingQueue<JSONObject>();

    //被重号过滤号码（每日凌晨清除）key cid,value Map<Long,Integer> key号码，value次数
    public static Map<Integer,Map<Long,Integer>> REPEAT_MAP = new ConcurrentHashMap<>();

    //重号过滤缓存，校验后先存入缓存，由单独线程更新redis
    public static BlockingQueue<String> REPEAT_CACHE = new LinkedBlockingQueue<>();

    //key:username_senddate;value:send_unsend_fail_balance
    public static Map<String, String> chargeMap = new ConcurrentHashMap<>();

    public synchronized static String chargeCount(int type, String key, int send, int unsend, int fail, double balance, double sms){
        if(type == 1){//set
            if(chargeMap.containsKey(key)){
                String[] val = chargeMap.get(key).split("_");
                String v = (send+Integer.parseInt(val[0]))+"_"+(unsend+Integer.parseInt(val[1]))+"_"+(fail+Integer.parseInt(val[2]))+"_"+balance+"_"+(sms+Double.parseDouble(val[4]));
                chargeMap.put(key, v);
            }else{
                chargeMap.put(key, send+"_"+unsend+"_"+fail+"_"+balance+"_"+sms);
            }
        }else{//get
            String v = chargeMap.get(key);
            String[] k = key.split("_");
            if(Integer.parseInt(k[1]) < Integer.parseInt(DateUtils.getCurrentDate())){
                chargeMap.remove(key);
                return v;
            }
            chargeMap.put(key, "0_0_0_0_0");
            return v;
        }
        return null;
    }
}
