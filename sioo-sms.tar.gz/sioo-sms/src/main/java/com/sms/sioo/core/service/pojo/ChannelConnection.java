package com.sms.sioo.core.service.pojo;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class ChannelConnection {

    /**
     * 通道编号
     */
    private Integer channelId;

    /**
     * 队列编号
     */
    private Integer no;

    /**
     * 类型:1验证码,2通知,3营销
     */
    private Integer type;

    /**
     * 连接数
     */
    private Integer num;

    /**
     * 流速
     */
    private Integer speed;
}
