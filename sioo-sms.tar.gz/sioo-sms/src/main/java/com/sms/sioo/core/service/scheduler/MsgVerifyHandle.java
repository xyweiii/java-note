package com.sms.sioo.core.service.scheduler;

import com.alibaba.fastjson.JSON;
import com.alibaba.fastjson.JSONObject;
import com.google.common.collect.Lists;
import com.sms.sioo.core.service.config.enums.MsgVerifyStatus;
import com.sms.sioo.core.service.repository.data.MsgVerifyData;
import com.sms.sioo.core.service.utils.SmsTaskQueue;
import org.apache.commons.collections.CollectionUtils;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.InitializingBean;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.mongodb.core.MongoTemplate;
import org.springframework.stereotype.Component;

import java.util.Date;
import java.util.List;
import java.util.concurrent.TimeUnit;
import java.util.stream.Collectors;

/**
 * Project:sioo-sms
 * File: com.sms.sioo.core.service.scheduler
 *
 * @author : xywei
 * @date : 2019-01-14
 * Copyright 2006-2019 Sioo Co., Ltd. All rights reserved.
 */

/**
 * 待审核短信存储到mongodb
 *
 * @author xywei
 */
@Component
public class MsgVerifyHandle implements Runnable, InitializingBean {

    public static final Logger LOGGER = LoggerFactory.getLogger(MsgVerifyHandle.class);

    @Autowired
    private MongoTemplate mongoTemplate;

    private static final List<JSONObject> msgVerifyList = Lists.newArrayList();

    @Override
    public void run() {
        try {
            while (true) {
                int count = SmsTaskQueue.SAVE_VERIFY_QUEUE.drainTo(msgVerifyList, 1000);
                if (count > 0) {
                    List<MsgVerifyData> dataList = msgVerifyList.stream().map(item -> {
                        MsgVerifyData msgVerifyData = JSON.parseObject(item.toJSONString(), MsgVerifyData.class);
                        msgVerifyData.setStatus(MsgVerifyStatus.WAITAUDIT.getCode());
                        return msgVerifyData;
                    }).collect(Collectors.toList());
                    mongoTemplate.insertAll(dataList);
                } else {
                    TimeUnit.MILLISECONDS.sleep(1000);
                }
            }
        } catch (Exception e) {
            e.printStackTrace();
            LOGGER.error(" MsgAuditHandle occur error,msg:" + e.getMessage());
        }
    }

    @Override
    public void afterPropertiesSet() {
        new Thread(this).start();
    }
}
